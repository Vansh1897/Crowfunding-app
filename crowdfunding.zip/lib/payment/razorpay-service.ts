import crypto from "crypto"

// In a real application, these would be environment variables
const RAZORPAY_KEY_ID = "rzp_test_your_key_id"
const RAZORPAY_KEY_SECRET = "your_key_secret"

export interface RazorpayOrderParams {
  amount: number // in paise (100 paise = ₹1)
  currency: string
  receipt: string
  notes?: Record<string, string>
}

export interface RazorpayOrder {
  id: string
  entity: string
  amount: number
  amount_paid: number
  amount_due: number
  currency: string
  receipt: string
  status: string
  attempts: number
  notes: Record<string, string>
  created_at: number
}

export interface RazorpayPaymentVerificationParams {
  razorpayOrderId: string
  razorpayPaymentId: string
  razorpaySignature: string
}

export async function createRazorpayOrder(params: RazorpayOrderParams): Promise<RazorpayOrder> {
  try {
    // In a real implementation, this would make an actual API call to Razorpay
    // For now, we'll simulate a successful response
    const order: RazorpayOrder = {
      id: `order_${Date.now()}`,
      entity: "order",
      amount: params.amount,
      amount_paid: 0,
      amount_due: params.amount,
      currency: params.currency,
      receipt: params.receipt,
      status: "created",
      attempts: 0,
      notes: params.notes || {},
      created_at: Math.floor(Date.now() / 1000),
    }

    return order
  } catch (error) {
    console.error("Error creating Razorpay order:", error)
    throw new Error("Failed to create payment order")
  }
}

export function verifyRazorpayPayment(params: RazorpayPaymentVerificationParams): boolean {
  const { razorpayOrderId, razorpayPaymentId, razorpaySignature } = params

  const payload = `${razorpayOrderId}|${razorpayPaymentId}`

  const expectedSignature = crypto.createHmac("sha256", RAZORPAY_KEY_SECRET).update(payload).digest("hex")

  return expectedSignature === razorpaySignature
}

export function getRazorpayConfig() {
  return {
    key_id: RAZORPAY_KEY_ID,
    key_secret: RAZORPAY_KEY_SECRET,
  }
}

