import { jwtVerify, SignJWT } from "jose"
import { cookies } from "next/headers"
import type { NextRequest, NextResponse } from "next/server"

// In a real application, these would be environment variables
const JWT_SECRET = new TextEncoder().encode("your-secret-key-replace-in-production")
const COOKIE_NAME = "auth-token"

export interface UserJwtPayload {
  id: string
  email: string
  name: string
  image?: string
}

export async function signJwtToken(payload: UserJwtPayload): Promise<string> {
  const token = await new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(JWT_SECRET)

  return token
}

export async function verifyJwtToken(token: string): Promise<UserJwtPayload | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET)
    return payload as UserJwtPayload
  } catch (error) {
    return null
  }
}

export function setAuthCookie(token: string, response?: NextResponse): void {
  const cookieStore = cookies()

  const cookieOptions = {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 7, // 7 days
    path: "/",
    sameSite: "strict" as const,
  }

  if (response) {
    // For API routes
    response.cookies.set(COOKIE_NAME, token, cookieOptions)
  } else {
    // For server components
    cookieStore.set(COOKIE_NAME, token, cookieOptions)
  }
}

export function getAuthCookie(request?: NextRequest): string | undefined {
  if (request) {
    // For middleware
    return request.cookies.get(COOKIE_NAME)?.value
  }

  // For server components
  const cookieStore = cookies()
  return cookieStore.get(COOKIE_NAME)?.value
}

export function removeAuthCookie(response?: NextResponse): void {
  const cookieStore = cookies()

  if (response) {
    // For API routes
    response.cookies.delete(COOKIE_NAME)
  } else {
    // For server components
    cookieStore.delete(COOKIE_NAME)
  }
}

export async function getCurrentUser(): Promise<UserJwtPayload | null> {
  const token = getAuthCookie()

  if (!token) {
    return null
  }

  return verifyJwtToken(token)
}

