"use server"

import { z } from "zod"
import { revalidatePath } from "next/cache"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import prisma from "@/lib/db"
import { stripe } from "@/lib/stripe"

const donationSchema = z.object({
  amount: z.coerce.number().min(1, "Amount must be at least $1"),
  message: z.string().optional(),
  anonymous: z.boolean().default(false),
})

export async function createDonation(campaignId: string, formData: FormData) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return { error: "You must be logged in to make a donation" }
  }

  const validatedFields = donationSchema.safeParse({
    amount: formData.get("amount"),
    message: formData.get("message"),
    anonymous: formData.get("anonymous") === "on",
  })

  if (!validatedFields.success) {
    return {
      error: validatedFields.error.flatten().fieldErrors,
    }
  }

  const { amount, message, anonymous } = validatedFields.data

  // Check if campaign exists
  const campaign = await prisma.campaign.findUnique({
    where: {
      id: campaignId,
    },
    include: {
      user: true,
    },
  })

  if (!campaign) {
    return { error: "Campaign not found" }
  }

  try {
    // Create Stripe checkout session
    const stripeSession = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: `Donation to ${campaign.title}`,
            },
            unit_amount: Math.round(amount * 100), // Convert to cents
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}/campaign/${campaign.slug}?donation=success`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/campaign/${campaign.slug}?donation=cancelled`,
      metadata: {
        campaignId,
        userId: session.user.id,
        message: message || "",
        anonymous: anonymous.toString(),
      },
    })

    // Create pending donation record
    await prisma.donation.create({
      data: {
        amount,
        message,
        anonymous,
        campaignId,
        userId: session.user.id,
        paymentId: stripeSession.id,
      },
    })

    // Create notification for campaign owner
    await prisma.notification.create({
      data: {
        type: "donation",
        message: `New donation of $${amount} to your campaign: ${campaign.title}`,
        userId: campaign.userId,
        relatedId: campaignId,
      },
    })

    return { checkoutUrl: stripeSession.url }
  } catch (error) {
    console.error("Error creating donation:", error)
    return { error: "Failed to process donation. Please try again." }
  }
}

export async function addComment(campaignId: string, formData: FormData) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return { error: "You must be logged in to add a comment" }
  }

  const content = formData.get("content") as string

  if (!content || content.length < 3) {
    return { error: "Comment must be at least 3 characters" }
  }

  // Check if campaign exists
  const campaign = await prisma.campaign.findUnique({
    where: {
      id: campaignId,
    },
    include: {
      user: true,
    },
  })

  if (!campaign) {
    return { error: "Campaign not found" }
  }

  // Create comment
  await prisma.comment.create({
    data: {
      content,
      campaignId,
      userId: session.user.id,
    },
  })

  // Create notification for campaign owner (if commenter is not the owner)
  if (campaign.userId !== session.user.id) {
    await prisma.notification.create({
      data: {
        type: "comment",
        message: `New comment on your campaign: ${campaign.title}`,
        userId: campaign.userId,
        relatedId: campaignId,
      },
    })
  }

  revalidatePath(`/campaign/${campaign.slug}`)
  return { success: true }
}

