"use server"

import { z } from "zod"
import { revalidatePath } from "next/cache"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import prisma from "@/lib/db"

const profileSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  bio: z.string().optional(),
  image: z.string().optional(),
})

export async function updateProfile(formData: FormData) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return { error: "You must be logged in to update your profile" }
  }

  const validatedFields = profileSchema.safeParse({
    name: formData.get("name"),
    bio: formData.get("bio"),
    image: formData.get("image"),
  })

  if (!validatedFields.success) {
    return {
      error: validatedFields.error.flatten().fieldErrors,
    }
  }

  const { name, bio, image } = validatedFields.data

  // Update user
  await prisma.user.update({
    where: {
      id: session.user.id,
    },
    data: {
      name,
      bio,
      image,
    },
  })

  revalidatePath("/dashboard/profile")
  return { success: true }
}

export async function markNotificationAsRead(notificationId: string) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return { error: "You must be logged in" }
  }

  // Check if notification belongs to user
  const notification = await prisma.notification.findUnique({
    where: {
      id: notificationId,
    },
  })

  if (!notification || notification.userId !== session.user.id) {
    return { error: "Notification not found" }
  }

  // Mark as read
  await prisma.notification.update({
    where: {
      id: notificationId,
    },
    data: {
      read: true,
    },
  })

  revalidatePath("/dashboard/notifications")
  return { success: true }
}

export async function markAllNotificationsAsRead() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return { error: "You must be logged in" }
  }

  // Mark all as read
  await prisma.notification.updateMany({
    where: {
      userId: session.user.id,
      read: false,
    },
    data: {
      read: true,
    },
  })

  revalidatePath("/dashboard/notifications")
  return { success: true }
}

