"use server"

import { z } from "zod"
import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import prisma from "@/lib/db"
import { slugify } from "@/lib/utils"

const campaignSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  description: z.string().min(20, "Description must be at least 20 characters"),
  story: z.string().min(100, "Story must be at least 100 characters"),
  goal: z.coerce.number().min(100, "Goal must be at least $100"),
  category: z.string().min(1, "Please select a category"),
  endDate: z.string().optional(),
  image: z.string().optional(),
})

export async function createCampaign(formData: FormData) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return { error: "You must be logged in to create a campaign" }
  }

  const validatedFields = campaignSchema.safeParse({
    title: formData.get("title"),
    description: formData.get("description"),
    story: formData.get("story"),
    goal: formData.get("goal"),
    category: formData.get("category"),
    endDate: formData.get("endDate"),
    image: formData.get("image"),
  })

  if (!validatedFields.success) {
    return {
      error: validatedFields.error.flatten().fieldErrors,
    }
  }

  const { title, description, story, goal, category, endDate, image } = validatedFields.data
  const slug = slugify(title)

  // Check if slug already exists
  const existingCampaign = await prisma.campaign.findUnique({
    where: {
      slug,
    },
  })

  if (existingCampaign) {
    return {
      error: {
        title: ["A campaign with a similar title already exists"],
      },
    }
  }

  // Create campaign
  const campaign = await prisma.campaign.create({
    data: {
      title,
      slug,
      description,
      story,
      goal,
      category,
      endDate: endDate ? new Date(endDate) : undefined,
      image,
      userId: session.user.id,
    },
  })

  revalidatePath("/")
  redirect(`/campaign/${campaign.slug}`)
}

export async function updateCampaign(campaignId: string, formData: FormData) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return { error: "You must be logged in to update a campaign" }
  }

  // Check if user owns the campaign
  const campaign = await prisma.campaign.findUnique({
    where: {
      id: campaignId,
    },
  })

  if (!campaign) {
    return { error: "Campaign not found" }
  }

  if (campaign.userId !== session.user.id) {
    return { error: "You do not have permission to update this campaign" }
  }

  const validatedFields = campaignSchema.safeParse({
    title: formData.get("title"),
    description: formData.get("description"),
    story: formData.get("story"),
    goal: formData.get("goal"),
    category: formData.get("category"),
    endDate: formData.get("endDate"),
    image: formData.get("image"),
  })

  if (!validatedFields.success) {
    return {
      error: validatedFields.error.flatten().fieldErrors,
    }
  }

  const { title, description, story, goal, category, endDate, image } = validatedFields.data
  const slug = slugify(title)

  // Check if new slug already exists (if title changed)
  if (slug !== campaign.slug) {
    const existingCampaign = await prisma.campaign.findUnique({
      where: {
        slug,
      },
    })

    if (existingCampaign) {
      return {
        error: {
          title: ["A campaign with a similar title already exists"],
        },
      }
    }
  }

  // Update campaign
  const updatedCampaign = await prisma.campaign.update({
    where: {
      id: campaignId,
    },
    data: {
      title,
      slug,
      description,
      story,
      goal,
      category,
      endDate: endDate ? new Date(endDate) : undefined,
      image,
    },
  })

  revalidatePath(`/campaign/${updatedCampaign.slug}`)
  redirect(`/campaign/${updatedCampaign.slug}`)
}

export async function addCampaignUpdate(campaignId: string, formData: FormData) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return { error: "You must be logged in to add an update" }
  }

  // Check if user owns the campaign
  const campaign = await prisma.campaign.findUnique({
    where: {
      id: campaignId,
    },
  })

  if (!campaign) {
    return { error: "Campaign not found" }
  }

  if (campaign.userId !== session.user.id) {
    return { error: "You do not have permission to update this campaign" }
  }

  const title = formData.get("title") as string
  const content = formData.get("content") as string

  if (!title || title.length < 5) {
    return { error: "Title must be at least 5 characters" }
  }

  if (!content || content.length < 20) {
    return { error: "Content must be at least 20 characters" }
  }

  // Create update
  await prisma.campaignUpdate.create({
    data: {
      title,
      content,
      campaignId,
    },
  })

  // Notify donors
  const donors = await prisma.donation.findMany({
    where: {
      campaignId,
    },
    select: {
      userId: true,
    },
    distinct: ["userId"],
  })

  // Create notifications for donors
  for (const donor of donors) {
    await prisma.notification.create({
      data: {
        type: "update",
        message: `New update on campaign: ${campaign.title}`,
        userId: donor.userId,
        relatedId: campaignId,
      },
    })
  }

  revalidatePath(`/campaign/${campaign.slug}`)
  return { success: true }
}

