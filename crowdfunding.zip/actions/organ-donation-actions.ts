"use server"

import { z } from "zod"
import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import prisma from "@/lib/db"

const organDonorSchema = z.object({
  donorType: z.enum(["deceased", "living"]),
  organTypes: z.array(z.string()).min(1, "Please select at least one organ type"),
})

export async function registerOrganDonor(formData: FormData) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return { error: "You must be logged in to register as an organ donor" }
  }

  // Check if user is already registered
  const existingDonor = await prisma.organDonor.findUnique({
    where: {
      userId: session.user.id,
    },
  })

  if (existingDonor) {
    return { error: "You are already registered as an organ donor" }
  }

  const donorType = formData.get("donorType") as string
  const organTypesFormData = formData.getAll("organTypes") as string[]

  const validatedFields = organDonorSchema.safeParse({
    donorType,
    organTypes: organTypesFormData,
  })

  if (!validatedFields.success) {
    return {
      error: validatedFields.error.flatten().fieldErrors,
    }
  }

  const { donorType: validatedDonorType, organTypes } = validatedFields.data

  // Register donor
  await prisma.organDonor.create({
    data: {
      donorType: validatedDonorType,
      organTypes,
      userId: session.user.id,
    },
  })

  revalidatePath("/organ-donation")
  redirect("/organ-donation/thank-you")
}

