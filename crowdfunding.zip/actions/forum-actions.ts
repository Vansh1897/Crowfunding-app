"use server"

import { z } from "zod"
import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import prisma from "@/lib/db"

const forumPostSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  content: z.string().min(20, "Content must be at least 20 characters"),
  category: z.string().min(1, "Please select a category"),
})

export async function createForumPost(formData: FormData) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return { error: "You must be logged in to create a post" }
  }

  const validatedFields = forumPostSchema.safeParse({
    title: formData.get("title"),
    content: formData.get("content"),
    category: formData.get("category"),
  })

  if (!validatedFields.success) {
    return {
      error: validatedFields.error.flatten().fieldErrors,
    }
  }

  const { title, content, category } = validatedFields.data

  // Create post
  const post = await prisma.forumPost.create({
    data: {
      title,
      content,
      category,
      userId: session.user.id,
    },
  })

  revalidatePath("/community")
  redirect(`/community/discussion/${post.id}`)
}

export async function addForumComment(postId: string, formData: FormData) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return { error: "You must be logged in to add a comment" }
  }

  const content = formData.get("content") as string

  if (!content || content.length < 3) {
    return { error: "Comment must be at least 3 characters" }
  }

  // Check if post exists
  const post = await prisma.forumPost.findUnique({
    where: {
      id: postId,
    },
    include: {
      user: true,
    },
  })

  if (!post) {
    return { error: "Post not found" }
  }

  // Create comment
  await prisma.forumComment.create({
    data: {
      content,
      postId,
      userId: session.user.id,
    },
  })

  // Create notification for post owner (if commenter is not the owner)
  if (post.userId !== session.user.id) {
    await prisma.notification.create({
      data: {
        type: "forum_comment",
        message: `New comment on your forum post: ${post.title}`,
        userId: post.userId,
        relatedId: postId,
      },
    })
  }

  revalidatePath(`/community/discussion/${postId}`)
  return { success: true }
}

export async function likeForumPost(postId: string) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return { error: "You must be logged in to like a post" }
  }

  // Check if post exists
  const post = await prisma.forumPost.findUnique({
    where: {
      id: postId,
    },
  })

  if (!post) {
    return { error: "Post not found" }
  }

  // Increment likes
  await prisma.forumPost.update({
    where: {
      id: postId,
    },
    data: {
      likes: {
        increment: 1,
      },
    },
  })

  revalidatePath(`/community/discussion/${postId}`)
  return { success: true }
}

