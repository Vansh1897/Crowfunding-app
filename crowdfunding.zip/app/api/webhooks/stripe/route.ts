import { type NextRequest, NextResponse } from "next/server"
import { headers } from "next/headers"
import { stripe } from "@/lib/stripe"
import prisma from "@/lib/db"

export async function POST(req: NextRequest) {
  const body = await req.text()
  const signature = headers().get("Stripe-Signature") as string

  let event

  try {
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch (error: any) {
    return new NextResponse(`Webhook Error: ${error.message}`, { status: 400 })
  }

  const session = event.data.object as any

  if (event.type === "checkout.session.completed") {
    const { campaignId, userId, message, anonymous } = session.metadata

    // Update donation status
    const donation = await prisma.donation.findFirst({
      where: {
        paymentId: session.id,
      },
    })

    if (donation) {
      await prisma.donation.update({
        where: {
          id: donation.id,
        },
        data: {
          paymentStatus: "completed",
        },
      })

      // Update campaign raised amount
      await prisma.campaign.update({
        where: {
          id: campaignId,
        },
        data: {
          raised: {
            increment: donation.amount,
          },
        },
      })
    }
  }

  return new NextResponse(null, { status: 200 })
}

