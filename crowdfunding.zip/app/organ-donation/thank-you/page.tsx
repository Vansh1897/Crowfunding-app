import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, Share2, Heart } from "lucide-react"

export default function ThankYouPage() {
  return (
    <div className="container py-16 md:py-24">
      <div className="mx-auto max-w-md text-center">
        <div className="mb-6 flex justify-center">
          <div className="rounded-full bg-green-100 p-3 dark:bg-green-900">
            <CheckCircle className="h-12 w-12 text-green-600 dark:text-green-400" />
          </div>
        </div>

        <h1 className="mb-4 text-3xl font-bold">Thank You for Registering!</h1>
        <p className="mb-8 text-muted-foreground">
          Your decision to become an organ donor could save up to 8 lives and enhance the lives of up to 75 others.
          Thank you for your generosity and compassion.
        </p>

        <Card>
          <CardHeader>
            <CardTitle>Your Registration is Complete</CardTitle>
            <CardDescription>What happens next?</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 text-left">
            <div className="flex items-start gap-3">
              <div className="rounded-full bg-primary/10 p-1">
                <CheckCircle className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="font-medium">Registration Confirmed</p>
                <p className="text-sm text-muted-foreground">Your information has been added to the donor registry.</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="rounded-full bg-primary/10 p-1">
                <Heart className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="font-medium">Share Your Decision</p>
                <p className="text-sm text-muted-foreground">
                  Let your family and loved ones know about your decision to be a donor.
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="rounded-full bg-primary/10 p-1">
                <Share2 className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="font-medium">Spread the Word</p>
                <p className="text-sm text-muted-foreground">Encourage others to register as organ donors too.</p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-center gap-4">
            <Button variant="outline" className="group" asChild>
              <Link href="/organ-donation">Learn More</Link>
            </Button>
            <Button className="group" asChild>
              <Link href="/">Return Home</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

