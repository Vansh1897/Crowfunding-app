import type { Metadata } from "next"
import { getServerSession } from "next-auth/next"
import { redirect } from "next/navigation"
import { authOptions } from "@/lib/auth"
import { OrganDonationForm } from "@/components/organ-donation/organ-donation-form"
import { SectionHeader } from "@/components/ui/section-header"

export const metadata: Metadata = {
  title: "Register as an Organ Donor | FundTogether",
  description: "Register to become an organ donor and save lives",
}

export default async function OrganDonationRegisterPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect("/login?callbackUrl=/organ-donation/register")
  }

  return (
    <div className="container py-10">
      <div className="mx-auto max-w-3xl space-y-8">
        <SectionHeader
          title="Register as an Organ Donor"
          description="Your decision to register as an organ donor can save and heal lives"
          centered
        />
        <OrganDonationForm />
      </div>
    </div>
  )
}

