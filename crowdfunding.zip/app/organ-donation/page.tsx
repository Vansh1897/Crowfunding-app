import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Heart, Users, Calendar, ArrowRight, CheckCircle, Info } from "lucide-react"

export default function OrganDonationPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary/10 to-blue-600/10 py-16 md:py-24">
        <div className="container grid gap-8 md:grid-cols-2 md:items-center">
          <div className="flex flex-col gap-6">
            <Badge className="w-fit">Organ Donation</Badge>
            <h1 className="text-4xl font-bold tracking-tight md:text-5xl">
              Give the gift of life through organ donation
            </h1>
            <p className="text-xl text-muted-foreground">
              One organ donor can save up to 8 lives and enhance the lives of up to 75 others through tissue donation.
            </p>
            <div className="flex flex-col gap-4 sm:flex-row">
              <Button size="lg" asChild>
                <Link href="/organ-donation/register">Register as a Donor</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/organ-donation/learn-more">Learn More</Link>
              </Button>
            </div>
          </div>
          <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
            <Image
              src="/placeholder.svg?height=800&width=1200"
              alt="Organ donation saves lives"
              fill
              className="object-cover"
              priority
            />
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white dark:bg-gray-950">
        <div className="container">
          <div className="grid gap-8 md:grid-cols-4">
            {[
              {
                stat: "100,000+",
                label: "People waiting for transplants",
                icon: <Users className="h-10 w-10 text-primary" />,
              },
              {
                stat: "17",
                label: "People die each day waiting",
                icon: <Calendar className="h-10 w-10 text-primary" />,
              },
              {
                stat: "8",
                label: "Lives saved by one donor",
                icon: <Heart className="h-10 w-10 text-primary" />,
              },
              {
                stat: "75",
                label: "Lives enhanced by tissue donation",
                icon: <CheckCircle className="h-10 w-10 text-primary" />,
              },
            ].map((item, i) => (
              <Card key={i} className="text-center">
                <CardHeader className="pb-2">
                  <div className="mx-auto">{item.icon}</div>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">{item.stat}</p>
                  <p className="text-muted-foreground">{item.label}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Information Tabs */}
      <section className="py-16">
        <div className="container">
          <div className="mb-10 flex flex-col gap-2 text-center">
            <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Learn About Organ Donation</h2>
            <p className="mx-auto max-w-2xl text-muted-foreground">
              Understanding the process and impact of organ donation
            </p>
          </div>

          <Tabs defaultValue="process" className="mb-8">
            <div className="flex justify-center">
              <TabsList>
                <TabsTrigger value="process">The Process</TabsTrigger>
                <TabsTrigger value="types">Types of Donation</TabsTrigger>
                <TabsTrigger value="myths">Common Myths</TabsTrigger>
                <TabsTrigger value="stories">Donor Stories</TabsTrigger>
              </TabsList>
            </div>
            <TabsContent value="process" className="mt-6">
              <div className="grid gap-8 md:grid-cols-2">
                <div>
                  <h3 className="mb-4 text-2xl font-bold">How Organ Donation Works</h3>
                  <div className="space-y-4">
                    <p>
                      Organ donation is the process of surgically removing an organ or tissue from one person (the
                      donor) and placing it into another person (the recipient). Transplantation is necessary because
                      the recipient's organ has failed or has been damaged by disease or injury.
                    </p>
                    <p>The donation process involves these key steps:</p>
                    <ol className="ml-6 list-decimal space-y-2">
                      <li>Registration as an organ donor</li>
                      <li>Medical evaluation to determine suitability</li>
                      <li>Matching donors with compatible recipients</li>
                      <li>The surgical procedure to recover and transplant organs</li>
                      <li>Post-transplant care and recovery</li>
                    </ol>
                    <p>
                      Organs that can be donated include the heart, kidneys, liver, lungs, pancreas, and intestines.
                      Tissues that can be donated include corneas, skin, heart valves, bone, blood vessels, and
                      connective tissue.
                    </p>
                  </div>
                </div>
                <div className="relative h-[400px] rounded-lg overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=800&width=1200"
                    alt="Organ donation process"
                    fill
                    className="object-cover"
                  />
                </div>
              </div>
            </TabsContent>
            <TabsContent value="types" className="mt-6">
              <div className="grid gap-8 md:grid-cols-2">
                <div>
                  <h3 className="mb-4 text-2xl font-bold">Types of Organ Donation</h3>
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-xl font-medium">Deceased Donation</h4>
                      <p className="text-muted-foreground">
                        Occurs when a person has died and their organs are donated to help others. Most organ and tissue
                        donations come from deceased donors.
                      </p>
                    </div>
                    <div>
                      <h4 className="text-xl font-medium">Living Donation</h4>
                      <p className="text-muted-foreground">
                        Occurs when a living person donates an organ or part of an organ to someone in need. Living
                        donors can donate a kidney, or a portion of the liver, lung, intestine, or pancreas.
                      </p>
                    </div>
                    <div>
                      <h4 className="text-xl font-medium">Directed Donation</h4>
                      <p className="text-muted-foreground">
                        When a living donor names a specific person to receive their donated organ.
                      </p>
                    </div>
                    <div>
                      <h4 className="text-xl font-medium">Non-Directed Donation</h4>
                      <p className="text-muted-foreground">
                        When a living donor does not name a recipient, allowing the organ to go to the next compatible
                        person on the national waiting list.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="relative h-[400px] rounded-lg overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=800&width=1200"
                    alt="Types of organ donation"
                    fill
                    className="object-cover"
                  />
                </div>
              </div>
            </TabsContent>
            <TabsContent value="myths" className="mt-6">
              <h3 className="mb-6 text-2xl font-bold">Common Myths About Organ Donation</h3>
              <Accordion type="single" collapsible className="w-full">
                {[
                  {
                    myth: "If I'm registered as a donor, doctors won't try to save my life",
                    fact: "This is false. Doctors and emergency personnel are focused solely on saving your life. Organ donation only becomes a possibility after all lifesaving efforts have failed and death has been declared.",
                  },
                  {
                    myth: "My religion doesn't support organ donation",
                    fact: "Most major religions support organ donation and consider it an act of charity. If you're unsure, consult with your religious leader.",
                  },
                  {
                    myth: "I'm too old to be a donor",
                    fact: "There's no age limit for organ donation. The decision to use your organs is based on health and organ function, not age.",
                  },
                  {
                    myth: "Rich or famous people get priority on the waiting list",
                    fact: "The organ allocation system is blind to wealth and social status. Factors like medical urgency, time on the waiting list, and biological compatibility determine who receives organs.",
                  },
                  {
                    myth: "My family will be charged if I donate my organs",
                    fact: "There is no cost to the donor's family for organ or tissue donation. All costs related to donation are paid by the recipient or their insurance.",
                  },
                ].map((item, i) => (
                  <AccordionItem key={i} value={`myth-${i}`}>
                    <AccordionTrigger className="text-left">
                      <div className="flex items-start gap-2">
                        <Info className="mt-0.5 h-5 w-5 flex-shrink-0 text-primary" />
                        <span>{item.myth}</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="pl-7">
                      <p>{item.fact}</p>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </TabsContent>
            <TabsContent value="stories" className="mt-6">
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {[
                  {
                    name: "James Wilson",
                    image: "/placeholder.svg?height=300&width=300",
                    story:
                      "After receiving a heart transplant, I've been able to watch my children grow up. I'm forever grateful to my donor for this second chance at life.",
                  },
                  {
                    name: "Maria Rodriguez",
                    image: "/placeholder.svg?height=300&width=300",
                    story:
                      "Donating a kidney to my brother was the most rewarding decision I've ever made. Seeing him healthy again has brought joy to our entire family.",
                  },
                  {
                    name: "The Johnson Family",
                    image: "/placeholder.svg?height=300&width=300",
                    story:
                      "After losing our daughter, we found comfort in knowing her organs saved four lives. Her legacy lives on through the people she helped.",
                  },
                ].map((story, i) => (
                  <Card key={i} className="overflow-hidden">
                    <div className="relative h-48">
                      <Image src={story.image || "/placeholder.svg"} alt={story.name} fill className="object-cover" />
                    </div>
                    <CardContent className="p-6">
                      <h4 className="mb-2 font-bold">{story.name}</h4>
                      <p className="text-sm italic">"{story.story}"</p>
                    </CardContent>
                    <CardFooter>
                      <Button variant="ghost" className="w-full" asChild>
                        <Link href={`/organ-donation/stories/${i}`}>Read Full Story</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Registration Steps */}
      <section className="bg-gray-50 py-16 dark:bg-gray-900">
        <div className="container">
          <div className="mb-10 flex flex-col gap-2 text-center">
            <h2 className="text-3xl font-bold tracking-tight md:text-4xl">How to Register as an Organ Donor</h2>
            <p className="mx-auto max-w-2xl text-muted-foreground">It only takes a few minutes to register</p>
          </div>

          <div className="grid gap-8 md:grid-cols-3">
            {[
              {
                title: "Register Online",
                description: "Complete a simple online form to register your decision to be an organ donor.",
                icon: <CheckCircle className="h-10 w-10 text-primary" />,
              },
              {
                title: "Tell Your Family",
                description: "Make sure your family knows about your decision to be an organ donor.",
                icon: <Users className="h-10 w-10 text-primary" />,
              },
              {
                title: "Get Your Donor Card",
                description: "Receive a digital donor card and add your donor status to your ID.",
                icon: <Heart className="h-10 w-10 text-primary" />,
              },
            ].map((step, i) => (
              <Card key={i} className="text-center">
                <CardHeader>
                  <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                    {step.icon}
                  </div>
                  <CardTitle className="mt-4">{step.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{step.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-10 text-center">
            <Button size="lg" asChild>
              <Link href="/organ-donation/register">Register Now</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Support Network */}
      <section className="py-16">
        <div className="container">
          <div className="mb-10 flex flex-col gap-2 text-center">
            <h2 className="text-3xl font-bold tracking-tight md:text-4xl">Support Network</h2>
            <p className="mx-auto max-w-2xl text-muted-foreground">
              Connect with others affected by organ donation and transplantation
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                title: "Donor Families",
                description:
                  "Connect with other families who have experienced the loss of a loved one and made the decision to donate.",
                link: "/organ-donation/support/donor-families",
              },
              {
                title: "Transplant Recipients",
                description: "Share experiences and get support from others who have received organ transplants.",
                link: "/organ-donation/support/recipients",
              },
              {
                title: "Living Donors",
                description:
                  "Connect with others who have donated organs while living and learn about their experiences.",
                link: "/organ-donation/support/living-donors",
              },
              {
                title: "Waiting List Support",
                description: "Resources and community for those currently waiting for an organ transplant.",
                link: "/organ-donation/support/waiting-list",
              },
              {
                title: "Healthcare Professionals",
                description: "Resources for medical professionals involved in organ donation and transplantation.",
                link: "/organ-donation/support/professionals",
              },
              {
                title: "Advocacy Groups",
                description: "Organizations working to increase awareness and support for organ donation.",
                link: "/organ-donation/support/advocacy",
              },
            ].map((group, i) => (
              <Card key={i}>
                <CardHeader>
                  <CardTitle>{group.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{group.description}</p>
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" className="w-full" asChild>
                    <Link href={group.link}>
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary py-16 text-primary-foreground">
        <div className="container text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight md:text-4xl">
            Be a hero. Register as an organ donor today.
          </h2>
          <p className="mx-auto mb-8 max-w-2xl text-primary-foreground/80">
            Your decision to register as an organ donor can save and heal lives.
          </p>
          <div className="flex flex-col gap-4 sm:flex-row sm:justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link href="/organ-donation/register">Register Now</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white hover:bg-white/10 hover:text-white"
              asChild
            >
              <Link href="/organ-donation/learn-more">Learn More</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

