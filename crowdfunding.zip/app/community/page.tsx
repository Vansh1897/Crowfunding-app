import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { MessageSquare, ThumbsUp, Users, Clock, Filter, Search } from "lucide-react"

export default function CommunityPage() {
  return (
    <div className="container py-8 md:py-12">
      <div className="mb-8 text-center">
        <h1 className="mb-2 text-3xl font-bold md:text-4xl">Community Forum</h1>
        <p className="mx-auto max-w-2xl text-muted-foreground">
          Connect with others, share experiences, and get advice from our supportive community of fundraisers and
          donors.
        </p>
      </div>

      <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="relative w-full md:max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search discussions..." className="pl-9" />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filter
          </Button>
          <Button size="sm">Start a Discussion</Button>
        </div>
      </div>

      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Tabs defaultValue="all" className="mb-8">
            <TabsList>
              <TabsTrigger value="all">All Topics</TabsTrigger>
              <TabsTrigger value="fundraising">Fundraising Tips</TabsTrigger>
              <TabsTrigger value="success">Success Stories</TabsTrigger>
              <TabsTrigger value="support">Support</TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="mt-6 space-y-4">
              {[
                {
                  title: "Tips for promoting your fundraiser on social media",
                  author: "Jessica Williams",
                  avatar: "/placeholder.svg?height=40&width=40",
                  category: "Fundraising Tips",
                  replies: 24,
                  likes: 47,
                  time: "2 hours ago",
                  excerpt:
                    "I've been running my fundraiser for a week now and wanted to share some strategies that have worked well for me on social media...",
                },
                {
                  title: "How to thank donors in a meaningful way",
                  author: "Michael Chen",
                  avatar: "/placeholder.svg?height=40&width=40",
                  category: "Fundraising Tips",
                  replies: 18,
                  likes: 32,
                  time: "5 hours ago",
                  excerpt:
                    "Expressing gratitude to your donors is crucial for building relationships and encouraging continued support...",
                },
                {
                  title: "Our community project reached its goal in just 10 days!",
                  author: "Sarah Johnson",
                  avatar: "/placeholder.svg?height=40&width=40",
                  category: "Success Stories",
                  replies: 32,
                  likes: 78,
                  time: "1 day ago",
                  excerpt:
                    "We're thrilled to announce that our neighborhood playground renovation project has reached its funding goal in record time...",
                },
                {
                  title: "Need advice on medical fundraising for my father",
                  author: "David Thompson",
                  avatar: "/placeholder.svg?height=40&width=40",
                  category: "Support",
                  replies: 15,
                  likes: 12,
                  time: "3 days ago",
                  excerpt:
                    "My father was recently diagnosed with a rare condition and we're starting a fundraiser to help with his medical expenses...",
                },
              ].map((discussion, i) => (
                <Card key={i}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between">
                      <div>
                        <CardTitle className="text-lg">
                          <Link href={`/community/discussion/${i}`} className="hover:underline">
                            {discussion.title}
                          </Link>
                        </CardTitle>
                        <CardDescription className="flex items-center gap-2">
                          <Badge variant="outline">{discussion.category}</Badge>
                          <span>•</span>
                          <Clock className="h-3 w-3" />
                          <span>{discussion.time}</span>
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="line-clamp-2 text-sm">{discussion.excerpt}</p>
                  </CardContent>
                  <CardFooter className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={discussion.avatar} alt={discussion.author} />
                        <AvatarFallback>{discussion.author.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span className="text-sm">{discussion.author}</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <MessageSquare className="h-4 w-4" />
                        <span>{discussion.replies}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <ThumbsUp className="h-4 w-4" />
                        <span>{discussion.likes}</span>
                      </div>
                    </div>
                  </CardFooter>
                </Card>
              ))}
              <Button variant="outline" className="w-full">
                Load More
              </Button>
            </TabsContent>
            <TabsContent value="fundraising" className="mt-6">
              {/* Similar content for fundraising tab */}
            </TabsContent>
            <TabsContent value="success" className="mt-6">
              {/* Similar content for success tab */}
            </TabsContent>
            <TabsContent value="support" className="mt-6">
              {/* Similar content for support tab */}
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Community Stats</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <div className="flex flex-col items-center rounded-lg bg-muted p-3">
                <Users className="mb-1 h-5 w-5 text-primary" />
                <span className="text-xl font-bold">12,458</span>
                <span className="text-xs text-muted-foreground">Members</span>
              </div>
              <div className="flex flex-col items-center rounded-lg bg-muted p-3">
                <MessageSquare className="mb-1 h-5 w-5 text-primary" />
                <span className="text-xl font-bold">8,392</span>
                <span className="text-xs text-muted-foreground">Discussions</span>
              </div>
              <div className="flex flex-col items-center rounded-lg bg-muted p-3">
                <ThumbsUp className="mb-1 h-5 w-5 text-primary" />
                <span className="text-xl font-bold">45,127</span>
                <span className="text-xs text-muted-foreground">Reactions</span>
              </div>
              <div className="flex flex-col items-center rounded-lg bg-muted p-3">
                <Clock className="mb-1 h-5 w-5 text-primary" />
                <span className="text-xl font-bold">24/7</span>
                <span className="text-xs text-muted-foreground">Active</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Popular Tags</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {[
                  "Medical",
                  "Education",
                  "Emergency",
                  "Tips",
                  "Success",
                  "Nonprofit",
                  "Community",
                  "Fundraising",
                  "Support",
                  "Gratitude",
                  "Social Media",
                  "Donors",
                ].map((tag, i) => (
                  <Badge key={i} variant="secondary">
                    {tag}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Active Members</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  {
                    name: "Jessica Williams",
                    avatar: "/placeholder.svg?height=40&width=40",
                    posts: 87,
                  },
                  {
                    name: "Michael Chen",
                    avatar: "/placeholder.svg?height=40&width=40",
                    posts: 64,
                  },
                  {
                    name: "Sarah Johnson",
                    avatar: "/placeholder.svg?height=40&width=40",
                    posts: 52,
                  },
                  {
                    name: "David Thompson",
                    avatar: "/placeholder.svg?height=40&width=40",
                    posts: 41,
                  },
                ].map((member, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Avatar>
                        <AvatarImage src={member.avatar} alt={member.name} />
                        <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <span className="font-medium">{member.name}</span>
                    </div>
                    <span className="text-sm text-muted-foreground">{member.posts} posts</span>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" className="w-full" asChild>
                <Link href="/community/members">View All Members</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

