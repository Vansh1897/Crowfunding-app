import type { Metadata } from "next"
import { getServerSession } from "next-auth/next"
import { redirect } from "next/navigation"
import { authOptions } from "@/lib/auth"
import CampaignForm from "@/components/campaign/campaign-form"

export const metadata: Metadata = {
  title: "Start a Fundraiser | FundTogether",
  description: "Create a new fundraising campaign on FundTogether",
}

export default async function StartFundraiserPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect("/login?callbackUrl=/start-fundraiser")
  }

  return (
    <div className="container py-10">
      <div className="mx-auto max-w-3xl space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold tracking-tight md:text-4xl">Start a Fundraiser</h1>
          <p className="mt-2 text-muted-foreground">Create a campaign to raise funds for a cause you care about</p>
        </div>
        <CampaignForm />
      </div>
    </div>
  )
}

