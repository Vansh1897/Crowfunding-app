import type { Metadata } from "next"
import Link from "next/link"
import RegisterForm from "@/components/auth/register-form"

export const metadata: Metadata = {
  title: "Register | FundTogether",
  description: "Create a new FundTogether account",
}

export default function RegisterPage() {
  return (
    <div className="container flex h-screen w-screen flex-col items-center justify-center">
      <Link href="/" className="mb-8 flex items-center text-lg font-bold">
        <span className="text-2xl font-bold bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
          FundTogether
        </span>
      </Link>
      <RegisterForm />
    </div>
  )
}

