import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Heart, Users, Lightbulb, TrendingUp, Award, ArrowRight } from "lucide-react"
import { AnimatedGradientBackground } from "@/components/ui/animated-gradient-background"
import { SectionHeader } from "@/components/ui/section-header"
import { CampaignCard } from "@/components/campaign/campaign-card"

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <AnimatedGradientBackground className="py-20 md:py-32">
        <div className="container grid gap-8 md:grid-cols-2 md:items-center">
          <div className="flex flex-col gap-6">
            <Badge className="w-fit">Crowdfunding Platform</Badge>
            <h1 className="text-4xl font-bold tracking-tight md:text-5xl lg:text-6xl">
              Fundraising for the people and causes you care about
            </h1>
            <p className="text-xl text-muted-foreground">
              Join millions who have raised over $10 billion for personal causes, medical emergencies, and community
              projects.
            </p>
            <div className="flex flex-col gap-4 sm:flex-row">
              <Button size="lg" className="group" asChild>
                <Link href="/start-fundraiser">
                  Start a Fundraiser
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/categories">Browse Fundraisers</Link>
              </Button>
            </div>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex -space-x-2">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="h-8 w-8 rounded-full border-2 border-background bg-gray-200" />
                ))}
              </div>
              <p>Trusted by over 100,000 fundraisers</p>
            </div>
          </div>
          <div className="relative h-[400px] rounded-lg overflow-hidden shadow-xl">
            <Image
              src="/placeholder.svg?height=800&width=1200"
              alt="People helping each other"
              fill
              className="object-cover"
              priority
            />
          </div>
        </div>
      </AnimatedGradientBackground>

      {/* Featured Campaigns */}
      <section className="py-16">
        <div className="container">
          <SectionHeader
            title="Featured Fundraisers"
            description="Join thousands of people supporting these important causes"
            centered
          />

          <Tabs defaultValue="trending" className="mb-8">
            <div className="flex justify-center">
              <TabsList>
                <TabsTrigger value="trending">Trending</TabsTrigger>
                <TabsTrigger value="urgent">Urgent</TabsTrigger>
                <TabsTrigger value="near-goal">Near Goal</TabsTrigger>
                <TabsTrigger value="recent">Recent</TabsTrigger>
              </TabsList>
            </div>
            <TabsContent value="trending" className="mt-6">
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {[
                  {
                    id: "1",
                    slug: "help-sarah-beat-cancer",
                    title: "Help Sarah Beat Cancer",
                    description:
                      "Support Sarah in her fight against stage 3 breast cancer. As a single mother of two, she needs our help with medical expenses.",
                    category: "Medical",
                    image: "/placeholder.svg?height=400&width=600",
                    raised: 42000,
                    goal: 50000,
                    endDate: new Date(Date.now() + 12 * 24 * 60 * 60 * 1000),
                    _count: {
                      donations: 358,
                    },
                  },
                  {
                    id: "2",
                    slug: "rebuild-after-hurricane-damage",
                    title: "Rebuild After Hurricane Damage",
                    description:
                      "Help the Johnson family rebuild their home after it was destroyed by Hurricane Maria. They lost everything and need our support.",
                    category: "Emergency",
                    image: "/placeholder.svg?height=400&width=600",
                    raised: 28500,
                    goal: 75000,
                    endDate: new Date(Date.now() + 20 * 24 * 60 * 60 * 1000),
                    _count: {
                      donations: 213,
                    },
                  },
                  {
                    id: "3",
                    slug: "college-fund-for-underprivileged-students",
                    title: "College Fund for Underprivileged Students",
                    description:
                      "Help provide scholarships for talented students from low-income backgrounds to pursue their dreams of higher education.",
                    category: "Education",
                    image: "/placeholder.svg?height=400&width=600",
                    raised: 15800,
                    goal: 30000,
                    endDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000),
                    _count: {
                      donations: 124,
                    },
                  },
                ].map((campaign) => (
                  <CampaignCard key={campaign.id} campaign={campaign} />
                ))}
              </div>
            </TabsContent>
            <TabsContent value="urgent" className="mt-6">
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {/* Similar campaign cards for urgent tab */}
              </div>
            </TabsContent>
            <TabsContent value="near-goal" className="mt-6">
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {/* Similar campaign cards for near-goal tab */}
              </div>
            </TabsContent>
            <TabsContent value="recent" className="mt-6">
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {/* Similar campaign cards for recent tab */}
              </div>
            </TabsContent>
          </Tabs>

          <div className="mt-10 text-center">
            <Button variant="outline" size="lg" className="group" asChild>
              <Link href="/categories">
                View All Fundraisers
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="bg-gray-50 py-16 dark:bg-gray-900">
        <div className="container">
          <SectionHeader title="Browse by Category" description="Find causes that matter to you" centered />

          <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6">
            {[
              { name: "Medical", icon: "🏥" },
              { name: "Education", icon: "🎓" },
              { name: "Emergency", icon: "🆘" },
              { name: "Community", icon: "🏘️" },
              { name: "Creative", icon: "🎨" },
              { name: "Nonprofit", icon: "🤝" },
              { name: "Animals", icon: "🐾" },
              { name: "Environment", icon: "🌱" },
              { name: "Sports", icon: "⚽" },
              { name: "Memorial", icon: "💐" },
              { name: "Faith", icon: "🙏" },
              { name: "Business", icon: "💼" },
            ].map((category, i) => (
              <Link
                key={i}
                href={`/categories/${category.name.toLowerCase()}`}
                className="flex flex-col items-center gap-2 rounded-lg bg-white p-6 text-center shadow-sm transition-all hover:shadow-md hover:-translate-y-1 dark:bg-gray-800"
              >
                <span className="text-4xl">{category.icon}</span>
                <span className="font-medium">{category.name}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16">
        <div className="container">
          <SectionHeader title="How It Works" description="Start your fundraiser in just a few minutes" centered />

          <div className="grid gap-8 md:grid-cols-3">
            {[
              {
                title: "Start your fundraiser",
                description: "Set up your fundraiser in minutes. Tell your story, add photos, and set your goal.",
                icon: <Lightbulb className="h-10 w-10 text-primary" />,
              },
              {
                title: "Share with friends",
                description:
                  "Spread the word through social media, email, and text. We'll provide you with tools to reach more people.",
                icon: <Users className="h-10 w-10 text-primary" />,
              },
              {
                title: "Manage donations",
                description:
                  "Receive donations directly to your bank account and keep supporters updated on your progress.",
                icon: <TrendingUp className="h-10 w-10 text-primary" />,
              },
            ].map((step, i) => (
              <Card key={i} className="overflow-hidden group hover:shadow-md transition-all">
                <CardContent className="p-6">
                  <div className="flex flex-col items-center gap-4 text-center">
                    <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 group-hover:bg-primary/20 transition-colors">
                      {step.icon}
                    </div>
                    <h3 className="text-xl font-bold">{step.title}</h3>
                    <p className="text-muted-foreground">{step.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-10 text-center">
            <Button size="lg" className="group" asChild>
              <Link href="/start-fundraiser">
                Start a Fundraiser
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Success Stories */}
      <section className="bg-gradient-to-r from-primary/10 to-blue-600/10 py-16">
        <div className="container">
          <SectionHeader title="Success Stories" description="Real people, real impact" centered />

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {[
              {
                name: "Michael Thompson",
                title: "Received life-saving surgery",
                image: "/placeholder.svg?height=300&width=300",
                quote:
                  "Thanks to the generosity of 412 donors, I was able to get the surgery I desperately needed. I'm forever grateful.",
              },
              {
                name: "The Wilson Family",
                title: "Rebuilt after house fire",
                image: "/placeholder.svg?height=300&width=300",
                quote:
                  "When we lost everything in the fire, this community stepped up. We're back on our feet because of you.",
              },
              {
                name: "Westside Elementary",
                title: "Funded new playground",
                image: "/placeholder.svg?height=300&width=300",
                quote:
                  "Our students now have a safe, modern playground thanks to the 289 donors who supported our campaign.",
              },
            ].map((story, i) => (
              <Card key={i} className="overflow-hidden group hover:shadow-md transition-all">
                <CardContent className="p-6">
                  <div className="mb-4 flex items-center gap-4">
                    <div className="relative h-16 w-16 overflow-hidden rounded-full border-2 border-primary/20">
                      <Image src={story.image || "/placeholder.svg"} alt={story.name} fill className="object-cover" />
                    </div>
                    <div>
                      <h3 className="font-bold">{story.name}</h3>
                      <p className="text-sm text-muted-foreground">{story.title}</p>
                    </div>
                  </div>
                  <p className="italic">"{story.quote}"</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-10 text-center">
            <Button variant="outline" size="lg" className="group" asChild>
              <Link href="/success-stories">
                Read More Success Stories
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Community & Organ Donation Highlight */}
      <section className="py-16">
        <div className="container">
          <div className="grid gap-8 md:grid-cols-2">
            {/* Community Forum */}
            <Card className="overflow-hidden group hover:shadow-md transition-all">
              <CardContent className="p-8">
                <div className="mb-6 flex items-center gap-3">
                  <div className="rounded-full bg-primary/10 p-3 group-hover:bg-primary/20 transition-colors">
                    <Users className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-2xl font-bold">Community Forum</h3>
                </div>
                <p className="mb-6 text-muted-foreground">
                  Connect with others, share experiences, and get advice from our supportive community of fundraisers
                  and donors.
                </p>
                <div className="mb-6 space-y-4">
                  <div className="rounded-lg bg-gray-50 p-4 dark:bg-gray-700">
                    <div className="mb-2 flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-gray-200" />
                      <div>
                        <p className="font-medium">Jessica W.</p>
                        <p className="text-xs text-muted-foreground">2 hours ago</p>
                      </div>
                    </div>
                    <p className="text-sm">
                      Any tips for promoting a fundraiser for a local animal shelter? We're trying to reach our goal by
                      next month.
                    </p>
                  </div>
                  <div className="rounded-lg bg-gray-50 p-4 dark:bg-gray-700">
                    <div className="mb-2 flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-gray-200" />
                      <div>
                        <p className="font-medium">David L.</p>
                        <p className="text-xs text-muted-foreground">5 hours ago</p>
                      </div>
                    </div>
                    <p className="text-sm">
                      Just reached our goal for my daughter's medical treatment! Thank you to everyone who shared advice
                      on this forum.
                    </p>
                  </div>
                </div>
                <Button className="group" asChild>
                  <Link href="/community">
                    Join the Conversation
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
              </CardContent>
            </Card>

            {/* Organ Donation */}
            <Card className="overflow-hidden group hover:shadow-md transition-all">
              <CardContent className="p-8">
                <div className="mb-6 flex items-center gap-3">
                  <div className="rounded-full bg-primary/10 p-3 group-hover:bg-primary/20 transition-colors">
                    <Heart className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-2xl font-bold">Organ Donation</h3>
                </div>
                <p className="mb-6 text-muted-foreground">
                  Learn about organ donation, register as a donor, and connect with others who have been impacted by
                  organ donation.
                </p>
                <div className="mb-6 space-y-4">
                  <div className="flex items-center gap-4 rounded-lg bg-gray-50 p-4 dark:bg-gray-700">
                    <Award className="h-8 w-8 text-primary" />
                    <div>
                      <p className="font-medium">Become a Donor</p>
                      <p className="text-sm text-muted-foreground">Register to become an organ donor and save lives.</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 rounded-lg bg-gray-50 p-4 dark:bg-gray-700">
                    <Users className="h-8 w-8 text-primary" />
                    <div>
                      <p className="font-medium">Support Network</p>
                      <p className="text-sm text-muted-foreground">
                        Connect with donor families and transplant recipients.
                      </p>
                    </div>
                  </div>
                </div>
                <Button className="group" asChild>
                  <Link href="/organ-donation">
                    Learn More
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary py-16 text-primary-foreground">
        <div className="container text-center">
          <h2 className="mb-4 text-3xl font-bold tracking-tight md:text-4xl">Ready to make a difference?</h2>
          <p className="mx-auto mb-8 max-w-2xl text-primary-foreground/80">
            Start a fundraiser today and turn compassion into action.
          </p>
          <div className="flex flex-col gap-4 sm:flex-row sm:justify-center">
            <Button size="lg" variant="secondary" className="group" asChild>
              <Link href="/start-fundraiser">
                Start a Fundraiser
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white hover:bg-white/10 hover:text-white group"
              asChild
            >
              <Link href="/categories">
                Donate to a Cause
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

