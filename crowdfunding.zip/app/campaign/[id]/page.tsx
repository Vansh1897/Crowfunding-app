import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Clock, Heart, Share2 } from "lucide-react"
import DonationForm from "@/components/donation-form"
import CampaignUpdates from "@/components/campaign-updates"
import CampaignComments from "@/components/campaign-comments"

export default function CampaignPage({ params }: { params: { id: string } }) {
  // This would normally fetch campaign data based on the ID
  const campaign = {
    id: params.id,
    title: "Help Sarah Beat Cancer",
    category: "Medical",
    image: "/placeholder.svg?height=600&width=1200",
    description:
      "Sarah was recently diagnosed with stage 3 breast cancer. She's a single mother of two young children and needs our help to cover her medical expenses and support her family during this difficult time. The funds will go towards her treatment, medication, and childcare while she undergoes chemotherapy.",
    organizer: {
      name: "John Smith",
      relationship: "Friend",
      image: "/placeholder.svg?height=100&width=100",
    },
    raised: 42000,
    goal: 50000,
    donors: 358,
    days: 12,
    updates: [
      {
        date: "2023-03-15",
        title: "Sarah started treatment",
        content:
          "Great news! Sarah had her first chemotherapy session today. The doctors are optimistic about her prognosis. Thank you all for your continued support.",
      },
      {
        date: "2023-02-28",
        title: "Thank you for your support",
        content:
          "We're overwhelmed by the generosity shown in just the first week of this campaign. Sarah is scheduled to begin treatment next week.",
      },
    ],
    comments: [
      {
        name: "Emily Johnson",
        date: "2023-03-10",
        comment: "Sending love and strength to Sarah and her family. Stay strong!",
        amount: 50,
      },
      {
        name: "Michael Rodriguez",
        date: "2023-03-08",
        comment: "As a cancer survivor myself, I know how tough this journey can be. You've got this, Sarah!",
        amount: 100,
      },
      {
        name: "Lisa Chen",
        date: "2023-03-05",
        comment: "Praying for a speedy recovery.",
        amount: 25,
      },
    ],
  }

  return (
    <div className="container py-8 md:py-12">
      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="mb-6">
            <Badge className="mb-4">{campaign.category}</Badge>
            <h1 className="mb-4 text-3xl font-bold md:text-4xl">{campaign.title}</h1>
          </div>

          <div className="mb-8 overflow-hidden rounded-lg">
            <Image
              src={campaign.image || "/placeholder.svg"}
              alt={campaign.title}
              width={1200}
              height={600}
              className="w-full object-cover"
            />
          </div>

          <div className="mb-8 md:hidden">
            <Card>
              <CardContent className="p-6">
                <div className="mb-4 space-y-2">
                  <div className="flex justify-between text-xl font-bold">
                    <span>${campaign.raised.toLocaleString()}</span>
                    <span className="text-muted-foreground">of ${campaign.goal.toLocaleString()}</span>
                  </div>
                  <Progress value={(campaign.raised / campaign.goal) * 100} className="h-2" />
                </div>

                <div className="mb-6 grid grid-cols-3 gap-2 text-center text-sm">
                  <div className="rounded-lg bg-muted p-2">
                    <div className="font-bold">{campaign.donors}</div>
                    <div className="text-muted-foreground">Donors</div>
                  </div>
                  <div className="rounded-lg bg-muted p-2">
                    <div className="font-bold">{campaign.days}</div>
                    <div className="text-muted-foreground">Days Left</div>
                  </div>
                  <div className="rounded-lg bg-muted p-2">
                    <div className="font-bold">{Math.round((campaign.raised / campaign.goal) * 100)}%</div>
                    <div className="text-muted-foreground">Funded</div>
                  </div>
                </div>

                <Button className="mb-4 w-full" size="lg">
                  Donate Now
                </Button>

                <div className="flex justify-center gap-2">
                  <Button variant="outline" size="sm">
                    <Heart className="mr-1 h-4 w-4" />
                    Follow
                  </Button>
                  <Button variant="outline" size="sm">
                    <Share2 className="mr-1 h-4 w-4" />
                    Share
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="story" className="mb-8">
            <TabsList className="w-full justify-start">
              <TabsTrigger value="story">Story</TabsTrigger>
              <TabsTrigger value="updates">Updates ({campaign.updates.length})</TabsTrigger>
              <TabsTrigger value="comments">Comments ({campaign.comments.length})</TabsTrigger>
              <TabsTrigger value="donors">Donors ({campaign.donors})</TabsTrigger>
            </TabsList>
            <TabsContent value="story" className="mt-6">
              <div className="mb-6 flex items-center gap-4">
                <Avatar>
                  <AvatarImage src={campaign.organizer.image} alt={campaign.organizer.name} />
                  <AvatarFallback>{campaign.organizer.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{campaign.organizer.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {campaign.organizer.relationship} • Campaign Organizer
                  </p>
                </div>
              </div>

              <div className="prose max-w-none dark:prose-invert">
                <p>{campaign.description}</p>
                <p>
                  Sarah has been a pillar of strength in our community for years, volunteering at the local food bank
                  and always being the first to help neighbors in need. Now it's our turn to help her.
                </p>
                <p>The funds raised will go towards:</p>
                <ul>
                  <li>Medical bills and treatment costs not covered by insurance</li>
                  <li>Medication and specialized care</li>
                  <li>Childcare for her two children (ages 5 and 8) during treatment</li>
                  <li>Living expenses while she's unable to work</li>
                </ul>
                <p>
                  Any amount you can contribute will make a difference. If you can't donate at this time, please
                  consider sharing this campaign with your network.
                </p>
                <p>
                  Thank you for your support during this challenging time. Sarah and her family are grateful for your
                  kindness and generosity.
                </p>
              </div>
            </TabsContent>
            <TabsContent value="updates" className="mt-6">
              <CampaignUpdates updates={campaign.updates} />
            </TabsContent>
            <TabsContent value="comments" className="mt-6">
              <CampaignComments comments={campaign.comments} />
            </TabsContent>
            <TabsContent value="donors" className="mt-6">
              <div className="space-y-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex items-center justify-between rounded-lg border p-4">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback>{String.fromCharCode(65 + Math.floor(Math.random() * 26))}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">Anonymous</p>
                        <p className="text-sm text-muted-foreground">
                          <Clock className="mr-1 inline-block h-3 w-3" />
                          {Math.floor(Math.random() * 24) + 1} hours ago
                        </p>
                      </div>
                    </div>
                    <p className="font-bold">${(Math.floor(Math.random() * 20) + 1) * 5}</p>
                  </div>
                ))}
                <Button variant="outline" className="w-full">
                  View All Donors
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="hidden lg:block">
          <div className="sticky top-24">
            <Card>
              <CardContent className="p-6">
                <div className="mb-4 space-y-2">
                  <div className="flex justify-between text-xl font-bold">
                    <span>${campaign.raised.toLocaleString()}</span>
                    <span className="text-muted-foreground">of ${campaign.goal.toLocaleString()}</span>
                  </div>
                  <Progress value={(campaign.raised / campaign.goal) * 100} className="h-2" />
                </div>

                <div className="mb-6 grid grid-cols-3 gap-2 text-center text-sm">
                  <div className="rounded-lg bg-muted p-2">
                    <div className="font-bold">{campaign.donors}</div>
                    <div className="text-muted-foreground">Donors</div>
                  </div>
                  <div className="rounded-lg bg-muted p-2">
                    <div className="font-bold">{campaign.days}</div>
                    <div className="text-muted-foreground">Days Left</div>
                  </div>
                  <div className="rounded-lg bg-muted p-2">
                    <div className="font-bold">{Math.round((campaign.raised / campaign.goal) * 100)}%</div>
                    <div className="text-muted-foreground">Funded</div>
                  </div>
                </div>

                <DonationForm />

                <div className="mt-4 flex justify-center gap-2">
                  <Button variant="outline" size="sm">
                    <Heart className="mr-1 h-4 w-4" />
                    Follow
                  </Button>
                  <Button variant="outline" size="sm">
                    <Share2 className="mr-1 h-4 w-4" />
                    Share
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

