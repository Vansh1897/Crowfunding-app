import Link from "next/link"
import Image from "next/image"
import { notFound } from "next/navigation"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import prisma from "@/lib/db"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Clock, Heart, Share2, Edit, PlusCircle, Users, Calendar, ArrowRight } from "lucide-react"
import DonationForm from "@/components/donation-form"
import CampaignUpdates from "@/components/campaign-updates"
import CampaignComments from "@/components/campaign-comments"
import { formatCurrency, calculateDaysLeft, calculateProgress, formatDate } from "@/lib/utils"
import { SectionHeader } from "@/components/ui/section-header"

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const campaign = await prisma.campaign.findUnique({
    where: {
      slug: params.slug,
    },
    select: {
      title: true,
      description: true,
    },
  })

  if (!campaign) {
    return {
      title: "Campaign Not Found | FundTogether",
      description: "The requested campaign could not be found.",
    }
  }

  return {
    title: `${campaign.title} | FundTogether`,
    description: campaign.description,
  }
}

export default async function CampaignPage({ params }: { params: { slug: string } }) {
  const session = await getServerSession(authOptions)

  const campaign = await prisma.campaign.findUnique({
    where: {
      slug: params.slug,
    },
    include: {
      user: {
        select: {
          id: true,
          name: true,
          image: true,
        },
      },
      updates: {
        orderBy: {
          createdAt: "desc",
        },
      },
      comments: {
        orderBy: {
          createdAt: "desc",
        },
        include: {
          user: {
            select: {
              name: true,
              image: true,
            },
          },
        },
      },
      donations: {
        where: {
          paymentStatus: "completed",
        },
        orderBy: {
          createdAt: "desc",
        },
        include: {
          user: {
            select: {
              name: true,
              image: true,
            },
          },
        },
      },
      _count: {
        select: {
          donations: {
            where: {
              paymentStatus: "completed",
            },
          },
        },
      },
    },
  })

  if (!campaign) {
    notFound()
  }

  const daysLeft = calculateDaysLeft(campaign.endDate)
  const progress = calculateProgress(campaign.raised, campaign.goal)
  const isOwner = session?.user?.id === campaign.user.id

  // Get similar campaigns
  const similarCampaigns = await prisma.campaign.findMany({
    where: {
      category: campaign.category,
      id: { not: campaign.id },
      status: "active",
    },
    take: 3,
    include: {
      _count: {
        select: {
          donations: true,
        },
      },
    },
  })

  return (
    <div className="container py-8 md:py-12">
      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="mb-6">
            <Badge className="mb-4">{campaign.category}</Badge>
            <h1 className="mb-4 text-3xl font-bold md:text-4xl">{campaign.title}</h1>
          </div>

          <div className="mb-8 overflow-hidden rounded-lg">
            <Image
              src={campaign.image || "/placeholder.svg?height=600&width=1200"}
              alt={campaign.title}
              width={1200}
              height={600}
              className="w-full object-cover"
            />
          </div>

          <div className="mb-8 md:hidden">
            <Card className="overflow-hidden">
              <CardContent className="p-6">
                <div className="mb-4 space-y-2">
                  <div className="flex justify-between text-xl font-bold">
                    <span>{formatCurrency(campaign.raised)}</span>
                    <span className="text-muted-foreground">of {formatCurrency(campaign.goal)}</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                  <p className="text-sm text-muted-foreground">
                    {daysLeft > 0 ? `${daysLeft} days left` : "Campaign ended"}
                  </p>
                </div>

                <div className="mb-6 grid grid-cols-3 gap-2 text-center text-sm">
                  <div className="rounded-lg bg-muted p-2">
                    <div className="font-bold">{campaign._count.donations}</div>
                    <div className="text-muted-foreground">Donors</div>
                  </div>
                  <div className="rounded-lg bg-muted p-2">
                    <div className="font-bold">{daysLeft}</div>
                    <div className="text-muted-foreground">Days Left</div>
                  </div>
                  <div className="rounded-lg bg-muted p-2">
                    <div className="font-bold">{progress}%</div>
                    <div className="text-muted-foreground">Funded</div>
                  </div>
                </div>

                <Button className="mb-4 w-full group" size="lg" asChild>
                  <a href="#donate">
                    Donate Now
                    <Heart className="ml-2 h-4 w-4 transition-transform group-hover:scale-110" />
                  </a>
                </Button>

                <div className="flex justify-center gap-2">
                  <Button variant="outline" size="sm">
                    <Heart className="mr-1 h-4 w-4" />
                    Follow
                  </Button>
                  <Button variant="outline" size="sm">
                    <Share2 className="mr-1 h-4 w-4" />
                    Share
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="story" className="mb-8">
            <TabsList className="w-full justify-start">
              <TabsTrigger value="story">Story</TabsTrigger>
              <TabsTrigger value="updates">Updates ({campaign.updates.length})</TabsTrigger>
              <TabsTrigger value="comments">Comments ({campaign.comments.length})</TabsTrigger>
              <TabsTrigger value="donors">Donors ({campaign._count.donations})</TabsTrigger>
            </TabsList>
            <TabsContent value="story" className="mt-6">
              <div className="mb-6 flex items-center gap-4">
                <Avatar>
                  <AvatarImage src={campaign.user.image || ""} alt={campaign.user.name || ""} />
                  <AvatarFallback>{campaign.user.name?.charAt(0) || "U"}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{campaign.user.name}</p>
                  <p className="text-sm text-muted-foreground">Campaign Organizer</p>
                </div>
                {isOwner && (
                  <Button variant="outline" size="sm" asChild className="ml-auto group">
                    <Link href={`/dashboard/campaigns/edit/${campaign.id}`}>
                      <Edit className="mr-2 h-4 w-4" />
                      Edit Campaign
                    </Link>
                  </Button>
                )}
              </div>

              <div className="prose max-w-none dark:prose-invert">
                {campaign.story.split("\n").map((paragraph, i) => (
                  <p key={i}>{paragraph}</p>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="updates" className="mt-6">
              {isOwner && (
                <div className="mb-6">
                  <Button asChild className="group">
                    <Link href={`/dashboard/campaigns/${campaign.id}/updates/new`}>
                      <PlusCircle className="mr-2 h-4 w-4" />
                      Add Update
                    </Link>
                  </Button>
                </div>
              )}
              <CampaignUpdates updates={campaign.updates} />
            </TabsContent>
            <TabsContent value="comments" className="mt-6">
              <CampaignComments comments={campaign.comments} campaignId={campaign.id} isLoggedIn={!!session?.user} />
            </TabsContent>
            <TabsContent value="donors" className="mt-6">
              <div className="space-y-4">
                {campaign.donations.map((donation) => (
                  <div
                    key={donation.id}
                    className="flex items-center justify-between rounded-lg border p-4 hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <Avatar>
                        {donation.anonymous ? (
                          <AvatarFallback>A</AvatarFallback>
                        ) : (
                          <>
                            <AvatarImage src={donation.user.image || ""} alt={donation.user.name || ""} />
                            <AvatarFallback>{donation.user.name?.charAt(0) || "U"}</AvatarFallback>
                          </>
                        )}
                      </Avatar>
                      <div>
                        <p className="font-medium">{donation.anonymous ? "Anonymous" : donation.user.name}</p>
                        <p className="text-sm text-muted-foreground flex items-center">
                          <Clock className="mr-1 inline-block h-3 w-3" />
                          {formatDate(donation.createdAt)}
                        </p>
                      </div>
                    </div>
                    <p className="font-bold">{formatCurrency(donation.amount)}</p>
                  </div>
                ))}
                {campaign.donations.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">No donations yet. Be the first to donate!</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="hidden lg:block">
          <div className="sticky top-24">
            <Card className="overflow-hidden">
              <CardContent className="p-6">
                <div className="mb-4 space-y-2">
                  <div className="flex justify-between text-xl font-bold">
                    <span>{formatCurrency(campaign.raised)}</span>
                    <span className="text-muted-foreground">of {formatCurrency(campaign.goal)}</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>

                <div className="mb-6 grid grid-cols-3 gap-2 text-center text-sm">
                  <div className="rounded-lg bg-muted p-2">
                    <div className="font-bold">{campaign._count.donations}</div>
                    <div className="text-muted-foreground">Donors</div>
                  </div>
                  <div className="rounded-lg bg-muted p-2">
                    <div className="font-bold">{daysLeft}</div>
                    <div className="text-muted-foreground">Days Left</div>
                  </div>
                  <div className="rounded-lg bg-muted p-2">
                    <div className="font-bold">{progress}%</div>
                    <div className="text-muted-foreground">Funded</div>
                  </div>
                </div>

                <div id="donate">
                  <DonationForm campaignId={campaign.id} />
                </div>

                <div className="mt-4 flex justify-center gap-2">
                  <Button variant="outline" size="sm">
                    <Heart className="mr-1 h-4 w-4" />
                    Follow
                  </Button>
                  <Button variant="outline" size="sm">
                    <Share2 className="mr-1 h-4 w-4" />
                    Share
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Similar Campaigns Section */}
      {similarCampaigns.length > 0 && (
        <section className="mt-16">
          <SectionHeader title="Similar Campaigns" description="You might also be interested in these campaigns" />

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {similarCampaigns.map((similarCampaign) => (
              <Card key={similarCampaign.id} className="overflow-hidden group hover:shadow-md transition-all">
                <div className="relative h-48">
                  <Image
                    src={similarCampaign.image || "/placeholder.svg?height=400&width=600"}
                    alt={similarCampaign.title}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <Badge className="absolute left-3 top-3">{similarCampaign.category}</Badge>
                </div>
                <CardContent className="p-4">
                  <h3 className="font-bold line-clamp-1 mb-1">
                    <Link href={`/campaign/${similarCampaign.slug}`} className="hover:text-primary transition-colors">
                      {similarCampaign.title}
                    </Link>
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{similarCampaign.description}</p>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">{formatCurrency(similarCampaign.raised)}</span>
                    <span className="text-muted-foreground">of {formatCurrency(similarCampaign.goal)}</span>
                  </div>
                  <Progress
                    value={calculateProgress(similarCampaign.raised, similarCampaign.goal)}
                    className="h-1 mb-2"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span className="flex items-center">
                      <Users className="mr-1 h-3 w-3" />
                      {similarCampaign._count.donations} donors
                    </span>
                    <span className="flex items-center">
                      <Calendar className="mr-1 h-3 w-3" />
                      {calculateDaysLeft(similarCampaign.endDate)} days left
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-8 text-center">
            <Button variant="outline" size="lg" className="group" asChild>
              <Link href={`/categories/${campaign.category.toLowerCase()}`}>
                View More {campaign.category} Campaigns
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
          </div>
        </section>
      )}
    </div>
  )
}

