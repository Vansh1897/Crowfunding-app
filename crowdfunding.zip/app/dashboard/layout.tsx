import type React from "react"
import { redirect } from "next/navigation"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { DashboardNav } from "@/components/dashboard/dashboard-nav"
import { MobileNav } from "@/components/dashboard/mobile-nav"

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect("/login?callbackUrl=/dashboard")
  }

  return (
    <div className="relative">
      <div className="flex h-16 items-center border-b px-4 md:px-6">
        <MobileNav />
        <div className="ml-auto flex items-center space-x-4">
          <div className="hidden md:flex">
            <span className="text-sm text-muted-foreground">Welcome, {session.user.name}</span>
          </div>
        </div>
      </div>
      <div className="container grid flex-1 gap-12 md:grid-cols-[200px_1fr] lg:grid-cols-[250px_1fr] py-10">
        <aside className="hidden md:block">
          <DashboardNav />
        </aside>
        <main>{children}</main>
      </div>
    </div>
  )
}

