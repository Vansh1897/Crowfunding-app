import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import prisma from "@/lib/db"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { formatCurrency } from "@/lib/utils"
import { Heart, CreditCard, TrendingUp, Users } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return null
  }

  const [userCampaigns, userDonations, totalRaised, recentDonations] = await Promise.all([
    prisma.campaign.findMany({
      where: {
        userId: session.user.id,
      },
      orderBy: {
        createdAt: "desc",
      },
      take: 3,
      include: {
        _count: {
          select: {
            donations: true,
          },
        },
      },
    }),
    prisma.donation.count({
      where: {
        userId: session.user.id,
      },
    }),
    prisma.campaign.aggregate({
      where: {
        userId: session.user.id,
      },
      _sum: {
        raised: true,
      },
    }),
    prisma.donation.findMany({
      where: {
        campaign: {
          userId: session.user.id,
        },
      },
      orderBy: {
        createdAt: "desc",
      },
      take: 5,
      include: {
        user: {
          select: {
            name: true,
            image: true,
          },
        },
        campaign: {
          select: {
            title: true,
            slug: true,
          },
        },
      },
    }),
  ])

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground">Welcome back, {session.user.name}</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Campaigns</CardTitle>
            <Heart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{userCampaigns.length}</div>
            <p className="text-xs text-muted-foreground">Campaigns you've created</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Donations</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{userDonations}</div>
            <p className="text-xs text-muted-foreground">Donations you've made</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Raised</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalRaised._sum.raised || 0)}</div>
            <p className="text-xs text-muted-foreground">Funds raised by your campaigns</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Recent Donors</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{recentDonations.length}</div>
            <p className="text-xs text-muted-foreground">Recent donations to your campaigns</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="lg:col-span-4">
          <CardHeader>
            <CardTitle>Your Campaigns</CardTitle>
            <CardDescription>Campaigns you've created and their progress</CardDescription>
          </CardHeader>
          <CardContent>
            {userCampaigns.length > 0 ? (
              <div className="space-y-4">
                {userCampaigns.map((campaign) => (
                  <div
                    key={campaign.id}
                    className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0"
                  >
                    <div>
                      <p className="font-medium">{campaign.title}</p>
                      <p className="text-sm text-muted-foreground">
                        {formatCurrency(campaign.raised)} of {formatCurrency(campaign.goal)} raised
                      </p>
                    </div>
                    <Button size="sm" variant="outline" asChild>
                      <Link href={`/campaign/${campaign.slug}`}>View</Link>
                    </Button>
                  </div>
                ))}
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/dashboard/campaigns">View All Campaigns</Link>
                </Button>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <p className="mb-4 text-muted-foreground">You haven't created any campaigns yet</p>
                <Button asChild>
                  <Link href="/start-fundraiser">Start a Fundraiser</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle>Recent Donations</CardTitle>
            <CardDescription>Recent donations to your campaigns</CardDescription>
          </CardHeader>
          <CardContent>
            {recentDonations.length > 0 ? (
              <div className="space-y-4">
                {recentDonations.map((donation) => (
                  <div
                    key={donation.id}
                    className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0"
                  >
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-muted" />
                      <div>
                        <p className="font-medium">{donation.anonymous ? "Anonymous" : donation.user.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {formatCurrency(donation.amount)} to {donation.campaign.title}
                        </p>
                      </div>
                    </div>
                    <Button size="sm" variant="ghost" asChild>
                      <Link href={`/campaign/${donation.campaign.slug}`}>View</Link>
                    </Button>
                  </div>
                ))}
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/dashboard/donations">View All Donations</Link>
                </Button>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <p className="text-muted-foreground">No recent donations</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

