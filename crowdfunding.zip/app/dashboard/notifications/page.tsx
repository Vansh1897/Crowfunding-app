import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import prisma from "@/lib/db"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { formatDate } from "@/lib/utils"
import { Card, CardContent } from "@/components/ui/card"
import { Bell, Check } from "lucide-react"
import { markAllNotificationsAsRead } from "@/actions/user-actions"

export default async function NotificationsPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return null
  }

  const notifications = await prisma.notification.findMany({
    where: {
      userId: session.user.id,
    },
    orderBy: {
      createdAt: "desc",
    },
  })

  const unreadCount = notifications.filter((n) => !n.read).length

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Notifications</h2>
          <p className="text-muted-foreground">Stay updated on your campaigns and donations</p>
        </div>
        {unreadCount > 0 && (
          <form action={markAllNotificationsAsRead}>
            <Button variant="outline" size="sm" type="submit">
              <Check className="mr-2 h-4 w-4" />
              Mark all as read
            </Button>
          </form>
        )}
      </div>

      {notifications.length > 0 ? (
        <div className="space-y-4">
          {notifications.map((notification) => (
            <Card key={notification.id} className={notification.read ? "bg-background" : "bg-muted/50"}>
              <CardContent className="flex items-start gap-4 p-4">
                <div className="rounded-full bg-primary/10 p-2">
                  <Bell className="h-4 w-4 text-primary" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <p className="font-medium">{notification.message}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(notification.createdAt)}</p>
                  </div>
                  {notification.relatedId && (
                    <div className="mt-2">
                      <Button variant="link" className="h-auto p-0" asChild>
                        <Link href={`/campaign/${notification.relatedId}`}>View Details</Link>
                      </Button>
                    </div>
                  )}
                </div>
                {!notification.read && (
                  <form
                    action={async () => {
                      "use server"
                      await prisma.notification.update({
                        where: { id: notification.id },
                        data: { read: true },
                      })
                    }}
                  >
                    <Button variant="ghost" size="sm" type="submit">
                      <Check className="h-4 w-4" />
                      <span className="sr-only">Mark as read</span>
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="rounded-full bg-primary/10 p-4 mb-4">
            <Bell className="h-8 w-8 text-primary" />
          </div>
          <h3 className="mb-2 text-xl font-semibold">No notifications</h3>
          <p className="max-w-md text-muted-foreground">
            You don't have any notifications yet. You'll receive updates about your campaigns and donations here.
          </p>
        </div>
      )}
    </div>
  )
}

