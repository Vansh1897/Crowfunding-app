import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import prisma from "@/lib/db"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { formatCurrency, formatDate } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"

export default async function DonationsPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return null
  }

  const donations = await prisma.donation.findMany({
    where: {
      userId: session.user.id,
    },
    orderBy: {
      createdAt: "desc",
    },
    include: {
      campaign: true,
    },
  })

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">My Donations</h2>
        <p className="text-muted-foreground">Track your contributions to campaigns</p>
      </div>

      {donations.length > 0 ? (
        <div className="rounded-md border">
          <div className="grid grid-cols-5 border-b bg-muted p-4 font-medium">
            <div className="col-span-2">Campaign</div>
            <div>Amount</div>
            <div>Date</div>
            <div>Status</div>
          </div>
          <div className="divide-y">
            {donations.map((donation) => (
              <div key={donation.id} className="grid grid-cols-5 items-center p-4">
                <div className="col-span-2">
                  <Link href={`/campaign/${donation.campaign.slug}`} className="font-medium hover:underline">
                    {donation.campaign.title}
                  </Link>
                </div>
                <div>{formatCurrency(donation.amount)}</div>
                <div>{formatDate(donation.createdAt)}</div>
                <div>
                  <Badge
                    variant={
                      donation.paymentStatus === "completed"
                        ? "success"
                        : donation.paymentStatus === "pending"
                          ? "outline"
                          : "destructive"
                    }
                  >
                    {donation.paymentStatus.charAt(0).toUpperCase() + donation.paymentStatus.slice(1)}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <h3 className="mb-2 text-xl font-semibold">No donations yet</h3>
          <p className="mb-6 max-w-md text-muted-foreground">
            You haven't made any donations yet. Browse campaigns to find causes you'd like to support.
          </p>
          <Button asChild>
            <Link href="/categories">Browse Campaigns</Link>
          </Button>
        </div>
      )}
    </div>
  )
}

