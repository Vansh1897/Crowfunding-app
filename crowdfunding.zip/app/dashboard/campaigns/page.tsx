import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import prisma from "@/lib/db"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { CampaignCard } from "@/components/campaign/campaign-card"
import { PlusCircle } from "lucide-react"

export default async function CampaignsPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    return null
  }

  const campaigns = await prisma.campaign.findMany({
    where: {
      userId: session.user.id,
    },
    orderBy: {
      createdAt: "desc",
    },
    include: {
      _count: {
        select: {
          donations: true,
        },
      },
    },
  })

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">My Campaigns</h2>
          <p className="text-muted-foreground">Manage your fundraising campaigns</p>
        </div>
        <Button asChild>
          <Link href="/start-fundraiser">
            <PlusCircle className="mr-2 h-4 w-4" />
            Start a Fundraiser
          </Link>
        </Button>
      </div>

      {campaigns.length > 0 ? (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {campaigns.map((campaign) => (
            <CampaignCard key={campaign.id} campaign={campaign} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <h3 className="mb-2 text-xl font-semibold">No campaigns yet</h3>
          <p className="mb-6 max-w-md text-muted-foreground">
            You haven't created any fundraising campaigns yet. Start your first campaign to begin raising funds for a
            cause you care about.
          </p>
          <Button asChild>
            <Link href="/start-fundraiser">
              <PlusCircle className="mr-2 h-4 w-4" />
              Start a Fundraiser
            </Link>
          </Button>
        </div>
      )}
    </div>
  )
}

