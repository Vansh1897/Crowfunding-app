"use client"

import React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Bell, Menu, Search, X, LogOut, User, Settings, Heart, PlusCircle } from "lucide-react"
import { cn } from "@/lib/utils"
import { useMobile } from "@/hooks/use-mobile"
import { useSession, signOut } from "next-auth/react"
import { NotificationIndicator } from "@/components/notification-indicator"

export default function Header() {
  const { data: session } = useSession()
  const pathname = usePathname()
  const [showSearch, setShowSearch] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const isMobile = useMobile()

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full transition-all duration-200",
        scrolled ? "bg-white/95 backdrop-blur-sm shadow-sm dark:bg-gray-950/95" : "bg-white dark:bg-gray-950",
      )}
    >
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6">
          <Link href="/" className="flex items-center space-x-2">
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
              FundTogether
            </span>
          </Link>

          {!isMobile && (
            <NavigationMenu className="hidden md:flex">
              <NavigationMenuList>
                <NavigationMenuItem>
                  <NavigationMenuTrigger>Browse</NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                      <ListItem href="/categories/medical" title="Medical">
                        Support medical treatments and healthcare needs
                      </ListItem>
                      <ListItem href="/categories/education" title="Education">
                        Help fund educational opportunities
                      </ListItem>
                      <ListItem href="/categories/emergency" title="Emergency">
                        Assist those facing unexpected crises
                      </ListItem>
                      <ListItem href="/categories/community" title="Community">
                        Support local community projects
                      </ListItem>
                      <ListItem href="/categories/creative" title="Creative">
                        Fund creative and artistic endeavors
                      </ListItem>
                      <ListItem href="/categories/nonprofit" title="Nonprofit">
                        Support nonprofit organizations and causes
                      </ListItem>
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link href="/how-it-works" legacyBehavior passHref>
                    <NavigationMenuLink className={navigationMenuTriggerStyle()}>How It Works</NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link href="/success-stories" legacyBehavior passHref>
                    <NavigationMenuLink className={navigationMenuTriggerStyle()}>Success Stories</NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link href="/community" legacyBehavior passHref>
                    <NavigationMenuLink className={navigationMenuTriggerStyle()}>Community</NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link href="/organ-donation" legacyBehavior passHref>
                    <NavigationMenuLink className={navigationMenuTriggerStyle()}>Organ Donation</NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
          )}
        </div>

        <div className="flex items-center gap-4">
          {showSearch ? (
            <div className="relative flex items-center md:w-64">
              <Input type="search" placeholder="Search campaigns..." className="pr-8" />
              <X
                className="absolute right-2 h-4 w-4 cursor-pointer text-muted-foreground"
                onClick={() => setShowSearch(false)}
              />
            </div>
          ) : (
            <Button variant="ghost" size="icon" onClick={() => setShowSearch(true)} className="hidden md:flex">
              <Search className="h-5 w-5" />
              <span className="sr-only">Search</span>
            </Button>
          )}

          {session?.user ? (
            <div className="hidden md:flex items-center gap-2">
              <Link href="/dashboard/notifications">
                <Button variant="ghost" size="icon" className="relative">
                  <Bell className="h-5 w-5" />
                  <NotificationIndicator />
                </Button>
              </Link>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={session.user.image || ""} alt={session.user.name || ""} />
                      <AvatarFallback>{session.user.name?.charAt(0) || "U"}</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <div className="flex flex-col space-y-1 p-2">
                    <p className="text-sm font-medium">{session.user.name}</p>
                    <p className="text-xs text-muted-foreground">{session.user.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard">
                      <User className="mr-2 h-4 w-4" />
                      <span>Dashboard</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard/campaigns">
                      <Heart className="mr-2 h-4 w-4" />
                      <span>My Campaigns</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/start-fundraiser">
                      <PlusCircle className="mr-2 h-4 w-4" />
                      <span>Start a Fundraiser</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard/settings">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => signOut({ callbackUrl: "/" })} className="cursor-pointer">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <Button asChild>
                <Link href="/start-fundraiser">Start a Fundraiser</Link>
              </Button>
            </div>
          ) : (
            <div className="hidden md:flex gap-2">
              <Button variant="outline" asChild>
                <Link href="/login">Login</Link>
              </Button>
              <Button asChild>
                <Link href="/start-fundraiser">Start a Fundraiser</Link>
              </Button>
            </div>
          )}

          {isMobile && (
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <div className="flex flex-col gap-6 py-6">
                  <Link
                    href="/"
                    className="text-2xl font-bold bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent"
                  >
                    FundTogether
                  </Link>

                  {session?.user ? (
                    <div className="flex items-center gap-4">
                      <Avatar>
                        <AvatarImage src={session.user.image || ""} alt={session.user.name || ""} />
                        <AvatarFallback>{session.user.name?.charAt(0) || "U"}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{session.user.name}</p>
                        <p className="text-sm text-muted-foreground">{session.user.email}</p>
                      </div>
                    </div>
                  ) : null}

                  <div className="relative">
                    <Input type="search" placeholder="Search campaigns..." />
                    <Search className="absolute right-3 top-3 h-4 w-4 text-muted-foreground" />
                  </div>

                  <nav className="flex flex-col space-y-4">
                    <Link href="/categories" className="font-medium">
                      Browse Categories
                    </Link>
                    <Link href="/how-it-works" className="font-medium">
                      How It Works
                    </Link>
                    <Link href="/success-stories" className="font-medium">
                      Success Stories
                    </Link>
                    <Link href="/community" className="font-medium">
                      Community
                    </Link>
                    <Link href="/organ-donation" className="font-medium">
                      Organ Donation
                    </Link>
                  </nav>

                  {session?.user ? (
                    <div className="flex flex-col gap-2 mt-auto">
                      <Link href="/dashboard" className="flex items-center gap-2 font-medium">
                        <User className="h-4 w-4" />
                        Dashboard
                      </Link>
                      <Link href="/dashboard/campaigns" className="flex items-center gap-2 font-medium">
                        <Heart className="h-4 w-4" />
                        My Campaigns
                      </Link>
                      <Link href="/dashboard/notifications" className="flex items-center gap-2 font-medium">
                        <Bell className="h-4 w-4" />
                        Notifications
                        <NotificationIndicator />
                      </Link>
                      <Link href="/dashboard/settings" className="flex items-center gap-2 font-medium">
                        <Settings className="h-4 w-4" />
                        Settings
                      </Link>
                      <Button asChild className="w-full">
                        <Link href="/start-fundraiser">Start a Fundraiser</Link>
                      </Button>
                      <Button variant="outline" className="w-full" onClick={() => signOut({ callbackUrl: "/" })}>
                        <LogOut className="mr-2 h-4 w-4" />
                        Logout
                      </Button>
                    </div>
                  ) : (
                    <div className="flex flex-col gap-2 mt-auto">
                      <Button variant="outline" asChild className="w-full">
                        <Link href="/login">Login</Link>
                      </Button>
                      <Button asChild className="w-full">
                        <Link href="/start-fundraiser">Start a Fundraiser</Link>
                      </Button>
                    </div>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          )}
        </div>
      </div>
    </header>
  )
}

const ListItem = React.forwardRef<React.ElementRef<"a">, React.ComponentPropsWithoutRef<"a"> & { title: string }>(
  ({ className, title, children, ...props }, ref) => {
    return (
      <li>
        <NavigationMenuLink asChild>
          <a
            ref={ref}
            className={cn(
              "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
              className,
            )}
            {...props}
          >
            <div className="text-sm font-medium leading-none">{title}</div>
            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">{children}</p>
          </a>
        </NavigationMenuLink>
      </li>
    )
  },
)
ListItem.displayName = "ListItem"

