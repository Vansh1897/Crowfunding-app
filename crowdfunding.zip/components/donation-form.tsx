"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { motion } from "framer-motion"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Icons } from "@/components/icons"
import { DollarSign, MessageSquare, User, ArrowRight } from "lucide-react"

const donationSchema = z.object({
  amount: z.coerce.number().min(1, "Amount must be at least ₹1"),
  message: z.string().optional(),
  anonymous: z.boolean().default(false),
})

type DonationFormValues = z.infer<typeof donationSchema>

interface DonationFormProps {
  campaignId: string
}

export default function DonationForm({ campaignId }: DonationFormProps) {
  const router = useRouter()
  const [amount, setAmount] = useState<string>("500")
  const [customAmount, setCustomAmount] = useState<string>("")
  const [showCustomAmount, setShowCustomAmount] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const [step, setStep] = useState(1)
  const [orderId, setOrderId] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<DonationFormValues>({
    resolver: zodResolver(donationSchema),
    defaultValues: {
      amount: 500,
      anonymous: false,
    },
  })

  const handleAmountChange = (value: string) => {
    if (value === "custom") {
      setShowCustomAmount(true)
      setAmount("custom")
    } else {
      setShowCustomAmount(false)
      setAmount(value)
      setValue("amount", Number.parseFloat(value))
    }
  }

  const handleCustomAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCustomAmount(e.target.value)
    setValue("amount", Number.parseFloat(e.target.value) || 0)
  }

  async function onSubmit(data: DonationFormValues) {
    setIsLoading(true)
    setError(null)

    try {
      // Create a Razorpay order
      const response = await fetch("/api/payments/create-order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          campaignId,
          amount: data.amount * 100, // Convert to paise
          currency: "INR",
          message: data.message,
          anonymous: data.anonymous,
        }),
      })

      const result = await response.json()

      if (!response.ok) {
        setError(result.message || "Failed to create payment order")
        return
      }

      setOrderId(result.orderId)
      setStep(3) // Move to payment step
    } catch (error) {
      setError("An error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handlePaymentSuccess = async (paymentId: string, orderId: string, signature: string) => {
    try {
      const response = await fetch("/api/payments/verify", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          paymentId,
          orderId,
          signature,
          campaignId,
        }),
      })

      const result = await response.json()

      if (!response.ok) {
        setError(result.message || "Payment verification failed")
        return
      }

      // Redirect to success page
      router.push(`/campaign/${campaignId}?donation=success`)
    } catch (error) {
      setError("Payment verification failed. Please contact support.")
    }
  }

  const handlePaymentFailure = (error: any) => {
    setError("Payment failed. Please try again.")
    console.error("Payment error:", error)
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {step === 1 && (
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
          className="space-y-4"
        >
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-primary" />
              <Label>Donation Amount</Label>
            </div>
            <RadioGroup value={amount} onValueChange={handleAmountChange} className="grid grid-cols-3 gap-2">
              {["100", "500", "1000", "2000", "5000", "custom"].map((value) => (
                <div key={value} className="flex items-center space-x-2">
                  <RadioGroupItem value={value} id={`amount-${value}`} className="sr-only" />
                  <Label
                    htmlFor={`amount-${value}`}
                    className={`flex h-10 w-full cursor-pointer items-center justify-center rounded-md border text-sm transition-colors ${
                      amount === value
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-input bg-background hover:bg-muted"
                    }`}
                  >
                    {value === "custom" ? "Custom" : `₹${value}`}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          {showCustomAmount && (
            <div className="space-y-2">
              <Label htmlFor="custom-amount">Enter Amount</Label>
              <div className="relative">
                <span className="absolute inset-y-0 left-3 flex items-center text-muted-foreground">₹</span>
                <Input
                  id="custom-amount"
                  type="number"
                  min="1"
                  step="1"
                  value={customAmount}
                  onChange={handleCustomAmountChange}
                  className="pl-7"
                  placeholder="Enter custom amount"
                />
              </div>
              {errors.amount && <p className="text-sm text-destructive">{errors.amount.message}</p>}
            </div>
          )}

          <Button
            type="button"
            className="w-full group"
            onClick={() => setStep(2)}
            disabled={!amount || (amount === "custom" && !customAmount)}
          >
            Continue
            <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Button>
        </motion.div>
      )}

      {step === 2 && (
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
          className="space-y-4"
        >
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-primary" />
              <Label htmlFor="message">Add a comment (optional)</Label>
            </div>
            <Textarea
              id="message"
              placeholder="Leave a message of support"
              className="resize-none min-h-[100px]"
              {...register("message")}
            />
          </div>

          <div className="flex items-start space-x-2">
            <div className="flex h-5 items-center">
              <Checkbox id="anonymous" {...register("anonymous")} />
            </div>
            <div className="grid gap-1.5 leading-none">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-primary" />
                <Label
                  htmlFor="anonymous"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Donate anonymously
                </Label>
              </div>
              <p className="text-xs text-muted-foreground">Your name will not be displayed publicly</p>
            </div>
          </div>

          <div className="flex gap-2">
            <Button type="button" variant="outline" className="flex-1" onClick={() => setStep(1)}>
              Back
            </Button>
            <Button type="submit" className="flex-1 group" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  Continue to Payment
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </>
              )}
            </Button>
          </div>
        </motion.div>
      )}

      {step === 3 && orderId && (
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
          className="space-y-4"
        >
          <div className="text-center mb-4">
            <h3 className="text-lg font-medium">Complete Your Donation</h3>
            <p className="text-sm text-muted-foreground">You're about to donate ₹{watch("amount")} to this campaign</p>
          </div>

          {/* This would be replaced with the actual RazorpayPayment component */}
          <div className="p-4 border rounded-md bg-muted/50">
            <p className="text-center text-sm text-muted-foreground mb-4">
              Click the button below to complete your payment securely with Razorpay
            </p>
            <Button
              type="button"
              className="w-full group"
              onClick={() => {
                // In a real implementation, this would trigger the Razorpay payment flow
                alert("In a real implementation, this would open the Razorpay payment window")
              }}
            >
              Pay with Razorpay
              <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Button>
          </div>

          <Button type="button" variant="outline" className="w-full" onClick={() => setStep(2)}>
            Back
          </Button>
        </motion.div>
      )}
    </form>
  )
}

