"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { motion } from "framer-motion"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Icons } from "@/components/icons"
import { registerOrganDonor } from "@/actions/organ-donation-actions"
import { Info } from "lucide-react"

const organDonorSchema = z.object({
  donorType: z.enum(["deceased", "living"]),
  organTypes: z.array(z.string()).min(1, "Please select at least one organ type"),
  consent: z.boolean().refine((val) => val === true, {
    message: "You must consent to organ donation",
  }),
})

type OrganDonorFormValues = z.infer<typeof organDonorSchema>

export function OrganDonationForm() {
  const router = useRouter()
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const [step, setStep] = useState(1)

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<OrganDonorFormValues>({
    resolver: zodResolver(organDonorSchema),
    defaultValues: {
      donorType: "deceased",
      organTypes: [],
      consent: false,
    },
  })

  const watchDonorType = watch("donorType")
  const watchOrganTypes = watch("organTypes")

  const handleOrganTypeChange = (value: string, checked: boolean) => {
    const currentValues = watchOrganTypes || []
    const newValues = checked ? [...currentValues, value] : currentValues.filter((type) => type !== value)

    setValue("organTypes", newValues, { shouldValidate: true })
  }

  async function onSubmit(data: OrganDonorFormValues) {
    setIsLoading(true)
    setError(null)

    try {
      const formData = new FormData()
      formData.append("donorType", data.donorType)
      data.organTypes.forEach((type) => {
        formData.append("organTypes", type)
      })

      const result = await registerOrganDonor(formData)

      if (result?.error) {
        setError(typeof result.error === "string" ? result.error : "An error occurred. Please try again.")
      }
    } catch (error) {
      setError("An error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const organTypes = [
    { value: "heart", label: "Heart" },
    { value: "lungs", label: "Lungs" },
    { value: "liver", label: "Liver" },
    { value: "kidneys", label: "Kidneys" },
    { value: "pancreas", label: "Pancreas" },
    { value: "intestines", label: "Intestines" },
    { value: "corneas", label: "Corneas" },
    { value: "tissue", label: "Tissue" },
    { value: "bone_marrow", label: "Bone Marrow" },
  ]

  return (
    <Card className="w-full">
      <CardHeader className="space-y-1">
        <div className="flex items-center justify-between">
          <CardTitle className="text-2xl font-bold">Organ Donor Registration</CardTitle>
          <div className="flex items-center space-x-1 text-sm text-muted-foreground">
            <span
              className={`flex h-6 w-6 items-center justify-center rounded-full ${step >= 1 ? "bg-primary text-primary-foreground" : "bg-muted"}`}
            >
              1
            </span>
            <span>-</span>
            <span
              className={`flex h-6 w-6 items-center justify-center rounded-full ${step >= 2 ? "bg-primary text-primary-foreground" : "bg-muted"}`}
            >
              2
            </span>
            <span>-</span>
            <span
              className={`flex h-6 w-6 items-center justify-center rounded-full ${step >= 3 ? "bg-primary text-primary-foreground" : "bg-muted"}`}
            >
              3
            </span>
          </div>
        </div>
        <CardDescription>Register to become an organ donor and help save lives</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {step === 1 && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.3 }}
              className="space-y-6"
            >
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Donation Type</h3>
                <p className="text-sm text-muted-foreground">
                  Please select the type of organ donation you would like to register for.
                </p>

                <RadioGroup
                  defaultValue={watchDonorType}
                  onValueChange={(value) => setValue("donorType", value as "deceased" | "living")}
                  className="grid gap-4 pt-2"
                >
                  <div className="flex items-start space-x-3 space-y-0">
                    <RadioGroupItem value="deceased" id="deceased" className="mt-1" />
                    <div className="grid gap-1.5">
                      <Label htmlFor="deceased" className="font-medium">
                        Deceased Donation
                      </Label>
                      <p className="text-sm text-muted-foreground">
                        Donate your organs after death to help others in need.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3 space-y-0">
                    <RadioGroupItem value="living" id="living" className="mt-1" />
                    <div className="grid gap-1.5">
                      <Label htmlFor="living" className="font-medium">
                        Living Donation
                      </Label>
                      <p className="text-sm text-muted-foreground">
                        Donate a kidney, or portion of the liver, lung, or pancreas while living.
                      </p>
                    </div>
                  </div>
                </RadioGroup>
                {errors.donorType && <p className="text-sm text-destructive">{errors.donorType.message}</p>}
              </div>

              <div className="rounded-lg border border-blue-200 bg-blue-50 p-4 dark:border-blue-900 dark:bg-blue-950">
                <div className="flex items-start gap-3">
                  <Info className="mt-0.5 h-5 w-5 text-blue-600 dark:text-blue-400" />
                  <div>
                    <h4 className="font-medium text-blue-800 dark:text-blue-300">Important Information</h4>
                    <p className="mt-1 text-sm text-blue-700 dark:text-blue-400">
                      Registering as an organ donor is a generous decision that can save lives. Your choice will be
                      recorded in the donor registry, and you can change your decision at any time.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <Button type="button" onClick={() => setStep(2)}>
                  Continue
                </Button>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.3 }}
              className="space-y-6"
            >
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Organ & Tissue Selection</h3>
                <p className="text-sm text-muted-foreground">
                  Please select which organs and tissues you would like to donate.
                </p>

                <div className="grid gap-4 pt-2 sm:grid-cols-2">
                  {organTypes.map((type) => (
                    <div key={type.value} className="flex items-start space-x-3 space-y-0">
                      <Checkbox
                        id={type.value}
                        checked={watchOrganTypes?.includes(type.value)}
                        onCheckedChange={(checked) => handleOrganTypeChange(type.value, checked as boolean)}
                      />
                      <div className="grid gap-1.5 leading-none">
                        <Label htmlFor={type.value} className="font-medium">
                          {type.label}
                        </Label>
                      </div>
                    </div>
                  ))}
                </div>
                {errors.organTypes && <p className="text-sm text-destructive">{errors.organTypes.message}</p>}
              </div>

              <div className="flex justify-between">
                <Button type="button" variant="outline" onClick={() => setStep(1)}>
                  Back
                </Button>
                <Button type="button" onClick={() => setStep(3)}>
                  Continue
                </Button>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.3 }}
              className="space-y-6"
            >
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Confirmation</h3>
                <p className="text-sm text-muted-foreground">
                  Please review your information and confirm your decision to register as an organ donor.
                </p>

                <div className="rounded-lg border p-4">
                  <h4 className="font-medium">Registration Summary</h4>
                  <div className="mt-3 space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Donation Type:</span>
                      <span className="text-sm font-medium">
                        {watchDonorType === "deceased" ? "Deceased Donation" : "Living Donation"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Selected Organs & Tissues:</span>
                      <span className="text-sm font-medium">
                        {watchOrganTypes?.length
                          ? watchOrganTypes.map((type) => organTypes.find((t) => t.value === type)?.label).join(", ")
                          : "None selected"}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-start space-x-3 space-y-0 pt-2">
                  <Checkbox
                    id="consent"
                    checked={watch("consent")}
                    onCheckedChange={(checked) => setValue("consent", checked as boolean, { shouldValidate: true })}
                  />
                  <div className="grid gap-1.5 leading-none">
                    <Label htmlFor="consent" className="font-medium">
                      I consent to organ donation
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      I understand that by registering, I am giving consent for the donation of my organs and tissues
                      after my death for the purpose of transplantation, research, or education.
                    </p>
                  </div>
                </div>
                {errors.consent && <p className="text-sm text-destructive">{errors.consent.message}</p>}
              </div>

              <div className="flex justify-between">
                <Button type="button" variant="outline" onClick={() => setStep(2)}>
                  Back
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
                      Registering...
                    </>
                  ) : (
                    "Complete Registration"
                  )}
                </Button>
              </div>
            </motion.div>
          )}
        </form>
      </CardContent>
    </Card>
  )
}

