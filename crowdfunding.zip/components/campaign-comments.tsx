"use client"

import type React from "react"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Clock, Send } from "lucide-react"
import { formatDate } from "@/lib/utils"
import { addComment } from "@/actions/donation-actions"

interface Comment {
  id: string
  content: string
  date: string
  user: {
    name: string
    image?: string | null
  }
  amount?: number
}

interface CampaignCommentsProps {
  comments: Comment[]
  campaignId: string
  isLoggedIn: boolean
}

export default function CampaignComments({ comments, campaignId, isLoggedIn }: CampaignCommentsProps) {
  const [commentText, setCommentText] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [localComments, setLocalComments] = useState<Comment[]>(comments)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!commentText.trim()) return

    setIsSubmitting(true)
    setError(null)

    try {
      const formData = new FormData()
      formData.append("content", commentText)

      const result = await addComment(campaignId, formData)

      if (result?.error) {
        setError(typeof result.error === "string" ? result.error : "Failed to post comment")
        return
      }

      // Add optimistic update
      const newComment = {
        id: Date.now().toString(),
        content: commentText,
        date: new Date().toISOString(),
        user: {
          name: "You", // This will be replaced when the page refreshes
          image: null,
        },
      }

      setLocalComments([newComment, ...localComments])
      setCommentText("")
    } catch (err) {
      setError("An error occurred. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="space-y-6">
      {isLoggedIn ? (
        <form onSubmit={handleSubmit} className="rounded-lg border p-4">
          <h3 className="mb-4 font-medium">Leave a comment</h3>
          <Textarea
            placeholder="Write a message of support..."
            className="mb-4 resize-none min-h-[100px]"
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            disabled={isSubmitting}
          />
          {error && <p className="text-sm text-destructive mb-4">{error}</p>}
          <div className="flex justify-end">
            <Button type="submit" disabled={isSubmitting || !commentText.trim()} className="group">
              {isSubmitting ? (
                "Posting..."
              ) : (
                <>
                  Post Comment
                  <Send className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </>
              )}
            </Button>
          </div>
        </form>
      ) : (
        <div className="rounded-lg border p-4 text-center">
          <p className="mb-4 text-muted-foreground">Please log in to leave a comment</p>
          <Button asChild>
            <a href="/login">Log In</a>
          </Button>
        </div>
      )}

      <div className="space-y-4">
        <AnimatePresence>
          {localComments.map((comment, index) => (
            <motion.div
              key={comment.id || index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="rounded-lg border p-4 hover:shadow-sm transition-shadow"
            >
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={comment.user?.image || ""} alt={comment.user?.name || ""} />
                    <AvatarFallback>{comment.user?.name?.charAt(0) || "U"}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{comment.user?.name}</p>
                    <p className="text-xs text-muted-foreground flex items-center">
                      <Clock className="mr-1 inline-block h-3 w-3" />
                      {formatDate(comment.date)}
                    </p>
                  </div>
                </div>
                {comment.amount && (
                  <div className="rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary">
                    ${comment.amount}
                  </div>
                )}
              </div>
              <p className="text-sm">{comment.content}</p>
            </motion.div>
          ))}
        </AnimatePresence>

        {localComments.length === 0 && (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No comments yet. Be the first to leave a comment!</p>
          </div>
        )}
      </div>
    </div>
  )
}

