"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { z } from "zod"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Icons } from "@/components/icons"
import { createCampaign, updateCampaign } from "@/actions/campaign-actions"
import { CheckCircle, ImageIcon, FileText, DollarSign, Calendar } from "lucide-react"

const campaignSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  description: z.string().min(20, "Description must be at least 20 characters"),
  story: z.string().min(100, "Story must be at least 100 characters"),
  goal: z.coerce.number().min(100, "Goal must be at least $100"),
  category: z.string().min(1, 'Please select  "Goal must be at least $100'),
  category: z.string().min(1, "Please select a category"),
  endDate: z.string().optional(),
  image: z.string().optional(),
})

type CampaignFormValues = z.infer<typeof campaignSchema>

interface CampaignFormProps {
  campaign?: {
    id: string
    title: string
    description: string
    story: string
    goal: number
    category: string
    endDate?: string
    image?: string
  }
}

export default function CampaignForm({ campaign }: CampaignFormProps) {
  const router = useRouter()
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const [activeTab, setActiveTab] = useState("basics")

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors, isValid },
  } = useForm<CampaignFormValues>({
    resolver: zodResolver(campaignSchema),
    defaultValues: campaign
      ? {
          title: campaign.title,
          description: campaign.description,
          story: campaign.story,
          goal: campaign.goal,
          category: campaign.category,
          endDate: campaign.endDate,
          image: campaign.image,
        }
      : undefined,
    mode: "onChange",
  })

  const handleCategoryChange = (value: string) => {
    setValue("category", value)
  }

  const watchTitle = watch("title")
  const watchDescription = watch("description")
  const watchGoal = watch("goal")
  const watchCategory = watch("category")

  async function onSubmit(data: CampaignFormValues) {
    setIsLoading(true)
    setError(null)

    try {
      const formData = new FormData()
      formData.append("title", data.title)
      formData.append("description", data.description)
      formData.append("story", data.story)
      formData.append("goal", data.goal.toString())
      formData.append("category", data.category)
      if (data.endDate) formData.append("endDate", data.endDate)
      if (data.image) formData.append("image", data.image)

      if (campaign) {
        const result = await updateCampaign(campaign.id, formData)
        if (result?.error) {
          setError(typeof result.error === "string" ? result.error : "An error occurred. Please try again.")
        }
      } else {
        const result = await createCampaign(formData)
        if (result?.error) {
          setError(typeof result.error === "string" ? result.error : "An error occurred. Please try again.")
        }
      }
    } catch (error) {
      setError("An error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const formSteps = [
    {
      id: "basics",
      label: "Basic Info",
      icon: <FileText className="h-4 w-4" />,
      isComplete: !!watchTitle && !!watchDescription && !!watchCategory,
    },
    {
      id: "story",
      label: "Your Story",
      icon: <FileText className="h-4 w-4" />,
      isComplete: false,
    },
    {
      id: "goal",
      label: "Funding Goal",
      icon: <DollarSign className="h-4 w-4" />,
      isComplete: !!watchGoal && watchGoal >= 100,
    },
    {
      id: "media",
      label: "Media",
      icon: <ImageIcon className="h-4 w-4" />,
      isComplete: true, // Optional
    },
  ]

  return (
    <Card className="w-full">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl font-bold">{campaign ? "Edit Campaign" : "Create Campaign"}</CardTitle>
        <CardDescription>
          {campaign
            ? "Update your fundraising campaign details"
            : "Fill in the details to create your fundraising campaign"}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            {formSteps.map((step) => (
              <TabsTrigger key={step.id} value={step.id} className="relative">
                <span className="flex items-center gap-2">
                  {step.icon}
                  <span className="hidden sm:inline">{step.label}</span>
                </span>
                {step.isComplete && <CheckCircle className="absolute -right-1 -top-1 h-4 w-4 text-green-500" />}
              </TabsTrigger>
            ))}
          </TabsList>

          <form onSubmit={handleSubmit(onSubmit)}>
            <TabsContent value="basics" className="mt-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Campaign Title</Label>
                <Input
                  id="title"
                  placeholder="Help fund my medical treatment"
                  {...register("title")}
                  className={errors.title ? "border-red-500" : ""}
                />
                {errors.title && <p className="text-sm text-destructive">{errors.title.message}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Short Description</Label>
                <Textarea
                  id="description"
                  placeholder="Briefly describe your campaign (this will appear in campaign cards)"
                  {...register("description")}
                  className={errors.description ? "border-red-500" : ""}
                />
                {errors.description && <p className="text-sm text-destructive">{errors.description.message}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select onValueChange={handleCategoryChange} defaultValue={campaign?.category}>
                  <SelectTrigger className={errors.category ? "border-red-500" : ""}>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Medical">Medical</SelectItem>
                    <SelectItem value="Education">Education</SelectItem>
                    <SelectItem value="Emergency">Emergency</SelectItem>
                    <SelectItem value="Community">Community</SelectItem>
                    <SelectItem value="Creative">Creative</SelectItem>
                    <SelectItem value="Nonprofit">Nonprofit</SelectItem>
                    <SelectItem value="Animals">Animals</SelectItem>
                    <SelectItem value="Environment">Environment</SelectItem>
                    <SelectItem value="Memorial">Memorial</SelectItem>
                  </SelectContent>
                </Select>
                {errors.category && <p className="text-sm text-destructive">{errors.category.message}</p>}
              </div>

              <div className="flex justify-end">
                <Button type="button" onClick={() => setActiveTab("story")}>
                  Continue
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="story" className="mt-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="story">Campaign Story</Label>
                <Textarea
                  id="story"
                  placeholder="Tell your full story. Why are you raising funds? How will the funds be used?"
                  className={`min-h-[300px] ${errors.story ? "border-red-500" : ""}`}
                  {...register("story")}
                />
                {errors.story && <p className="text-sm text-destructive">{errors.story.message}</p>}
                <p className="text-xs text-muted-foreground">
                  Tip: Be detailed and authentic. Share why this cause matters to you and how the funds will be used.
                </p>
              </div>

              <div className="flex justify-between">
                <Button type="button" variant="outline" onClick={() => setActiveTab("basics")}>
                  Back
                </Button>
                <Button type="button" onClick={() => setActiveTab("goal")}>
                  Continue
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="goal" className="mt-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="goal">Fundraising Goal ($)</Label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-3 flex items-center text-muted-foreground">$</span>
                  <Input
                    id="goal"
                    type="number"
                    min="100"
                    placeholder="5000"
                    className={`pl-7 ${errors.goal ? "border-red-500" : ""}`}
                    {...register("goal")}
                  />
                </div>
                {errors.goal && <p className="text-sm text-destructive">{errors.goal.message}</p>}
                <p className="text-xs text-muted-foreground">
                  Set a realistic goal based on your needs. You can receive funds even if you don't reach your goal.
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="endDate">End Date (Optional)</Label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input id="endDate" type="date" className="pl-9" {...register("endDate")} />
                </div>
                {errors.endDate && <p className="text-sm text-destructive">{errors.endDate.message}</p>}
                <p className="text-xs text-muted-foreground">
                  Setting an end date creates urgency. Leave blank for an ongoing campaign.
                </p>
              </div>

              <div className="flex justify-between">
                <Button type="button" variant="outline" onClick={() => setActiveTab("story")}>
                  Back
                </Button>
                <Button type="button" onClick={() => setActiveTab("media")}>
                  Continue
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="media" className="mt-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="image">Campaign Image URL</Label>
                <div className="relative">
                  <ImageIcon className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="image"
                    className="pl-9"
                    placeholder="https://example.com/image.jpg"
                    {...register("image")}
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  Enter a URL for your campaign image. Recommended size: 1200x600 pixels.
                </p>
                {errors.image && <p className="text-sm text-destructive">{errors.image.message}</p>}
              </div>

              <div className="rounded-lg border border-dashed p-8 text-center">
                <div className="mx-auto flex max-w-[420px] flex-col items-center justify-center">
                  <ImageIcon className="h-10 w-10 text-muted-foreground" />
                  <p className="mt-2 text-sm font-medium">Drag and drop your image here</p>
                  <p className="text-xs text-muted-foreground">PNG, JPG or GIF, up to 10MB</p>
                  <Button type="button" variant="outline" size="sm" className="mt-4">
                    Choose File
                  </Button>
                </div>
              </div>

              <div className="flex justify-between">
                <Button type="button" variant="outline" onClick={() => setActiveTab("goal")}>
                  Back
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
                      {campaign ? "Updating..." : "Creating..."}
                    </>
                  ) : campaign ? (
                    "Update Campaign"
                  ) : (
                    "Create Campaign"
                  )}
                </Button>
              </div>
            </TabsContent>
          </form>
        </Tabs>
      </CardContent>
    </Card>
  )
}

