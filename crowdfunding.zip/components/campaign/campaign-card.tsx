"use client"

import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Users, Heart } from "lucide-react"
import { formatCurrency, calculateDaysLeft, calculateProgress } from "@/lib/utils"

interface CampaignCardProps {
  campaign: {
    id: string
    slug: string
    title: string
    description: string
    image?: string | null
    category: string
    raised: number
    goal: number
    endDate?: Date | null
    _count: {
      donations: number
    }
  }
}

export function CampaignCard({ campaign }: CampaignCardProps) {
  const daysLeft = calculateDaysLeft(campaign.endDate)
  const progress = calculateProgress(campaign.raised, campaign.goal)

  return (
    <motion.div whileHover={{ y: -5 }} transition={{ duration: 0.2 }}>
      <Card className="overflow-hidden h-full flex flex-col group">
        <div className="relative h-48 overflow-hidden">
          <Image
            src={campaign.image || "/placeholder.svg?height=400&width=600"}
            alt={campaign.title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <Badge className="absolute left-3 top-3 z-10">{campaign.category}</Badge>
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <motion.div
            className="absolute right-3 top-3 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            whileHover={{ scale: 1.1 }}
          >
            <Button size="icon" variant="secondary" className="rounded-full h-8 w-8">
              <Heart className="h-4 w-4" />
            </Button>
          </motion.div>
        </div>
        <CardHeader className="flex-none">
          <CardTitle className="line-clamp-2">
            <Link href={`/campaign/${campaign.slug}`} className="hover:text-primary transition-colors">
              {campaign.title}
            </Link>
          </CardTitle>
          <CardDescription className="flex items-center gap-1">
            <Users className="h-3 w-3" />
            {campaign._count.donations} donors
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2 flex-grow">
          <div className="flex justify-between text-sm">
            <span className="font-medium">{formatCurrency(campaign.raised)}</span>
            <span className="text-muted-foreground">raised of {formatCurrency(campaign.goal)}</span>
          </div>
          <Progress value={progress} className="h-2" />
          <p className="text-sm text-muted-foreground">{daysLeft > 0 ? `${daysLeft} days left` : "Campaign ended"}</p>
        </CardContent>
        <CardFooter className="flex-none">
          <Button className="w-full group-hover:bg-primary/90 transition-colors" asChild>
            <Link href={`/campaign/${campaign.slug}`}>Donate Now</Link>
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  )
}

