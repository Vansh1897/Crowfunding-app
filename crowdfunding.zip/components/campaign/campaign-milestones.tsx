"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Clock, AlertCircle, ArrowRight } from "lucide-react"
import { formatCurrency } from "@/lib/utils"
import type { MilestoneData } from "@/lib/blockchain/smart-contract"

interface CampaignMilestonesProps {
  milestones: MilestoneData[]
  isOwner: boolean
  onComplete?: (milestoneId: number) => void
  onApprove?: (milestoneId: number) => void
  onWithdraw?: (milestoneId: number) => void
}

export function CampaignMilestones({
  milestones,
  isOwner,
  onComplete,
  onApprove,
  onWithdraw,
}: CampaignMilestonesProps) {
  const [expandedMilestone, setExpandedMilestone] = useState<number | null>(null)

  const toggleExpand = (id: number) => {
    setExpandedMilestone(expandedMilestone === id ? null : id)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold">Campaign Milestones</h3>
        <Badge variant="outline" className="px-3 py-1">
          {milestones.filter((m) => m.completed && m.approved).length} of {milestones.length} completed
        </Badge>
      </div>

      <div className="space-y-4">
        {milestones.map((milestone, index) => (
          <motion.div
            key={milestone.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card
              className={`overflow-hidden transition-all ${milestone.completed && milestone.approved ? "border-green-200 dark:border-green-900" : ""}`}
            >
              <CardHeader className="pb-2 cursor-pointer" onClick={() => toggleExpand(milestone.id)}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={`rounded-full p-1 ${
                        milestone.completed && milestone.approved
                          ? "bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-400"
                          : milestone.completed
                            ? "bg-yellow-100 text-yellow-600 dark:bg-yellow-900 dark:text-yellow-400"
                            : "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400"
                      }`}
                    >
                      {milestone.completed && milestone.approved ? (
                        <CheckCircle className="h-5 w-5" />
                      ) : milestone.completed ? (
                        <Clock className="h-5 w-5" />
                      ) : (
                        <AlertCircle className="h-5 w-5" />
                      )}
                    </div>
                    <CardTitle className="text-lg">{milestone.title}</CardTitle>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-medium">{formatCurrency(milestone.amount)}</span>
                    <Badge
                      variant={
                        milestone.completed && milestone.approved
                          ? "success"
                          : milestone.completed
                            ? "outline"
                            : "secondary"
                      }
                    >
                      {milestone.completed && milestone.approved
                        ? "Completed"
                        : milestone.completed
                          ? "Pending Approval"
                          : "In Progress"}
                    </Badge>
                    <ArrowRight
                      className={`h-4 w-4 transition-transform ${expandedMilestone === milestone.id ? "rotate-90" : ""}`}
                    />
                  </div>
                </div>
              </CardHeader>
              {expandedMilestone === milestone.id && (
                <CardContent className="pt-4">
                  <p className="mb-4 text-muted-foreground">{milestone.description}</p>

                  {isOwner && !milestone.completed && (
                    <Button variant="outline" className="group" onClick={() => onComplete?.(milestone.id)}>
                      Mark as Completed
                      <CheckCircle className="ml-2 h-4 w-4" />
                    </Button>
                  )}

                  {!isOwner && milestone.completed && !milestone.approved && (
                    <Button variant="outline" className="group" onClick={() => onApprove?.(milestone.id)}>
                      Approve Milestone
                      <CheckCircle className="ml-2 h-4 w-4" />
                    </Button>
                  )}

                  {isOwner && milestone.completed && milestone.approved && (
                    <Button className="group" onClick={() => onWithdraw?.(milestone.id)}>
                      Withdraw Funds
                      <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                    </Button>
                  )}
                </CardContent>
              )}
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

