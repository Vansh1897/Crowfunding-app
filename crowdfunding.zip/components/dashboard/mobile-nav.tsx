"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { cn } from "@/lib/utils"
import { LayoutDashboard, Heart, Bell, Settings, CreditCard, User, PlusCircle, Menu } from "lucide-react"

const navItems = [
  {
    title: "Overview",
    href: "/dashboard",
    icon: <LayoutDashboard className="mr-2 h-4 w-4" />,
  },
  {
    title: "My Campaigns",
    href: "/dashboard/campaigns",
    icon: <Heart className="mr-2 h-4 w-4" />,
  },
  {
    title: "My Donations",
    href: "/dashboard/donations",
    icon: <CreditCard className="mr-2 h-4 w-4" />,
  },
  {
    title: "Notifications",
    href: "/dashboard/notifications",
    icon: <Bell className="mr-2 h-4 w-4" />,
  },
  {
    title: "Profile",
    href: "/dashboard/profile",
    icon: <User className="mr-2 h-4 w-4" />,
  },
  {
    title: "Settings",
    href: "/dashboard/settings",
    icon: <Settings className="mr-2 h-4 w-4" />,
  },
]

export function MobileNav() {
  const [open, setOpen] = useState(false)
  const pathname = usePathname()

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu className="h-5 w-5" />
          <span className="sr-only">Toggle menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[240px] sm:w-[300px]">
        <div className="flex flex-col gap-6 py-6">
          <Link
            href="/"
            className="text-2xl font-bold bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent"
          >
            FundTogether
          </Link>
          <nav className="flex flex-col space-y-1">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href} onClick={() => setOpen(false)}>
                <Button
                  variant={pathname === item.href ? "default" : "ghost"}
                  className={cn(
                    "w-full justify-start",
                    pathname === item.href ? "" : "hover:bg-muted hover:text-foreground",
                  )}
                >
                  {item.icon}
                  {item.title}
                </Button>
              </Link>
            ))}
            <div className="mt-4">
              <Button className="w-full" asChild onClick={() => setOpen(false)}>
                <Link href="/start-fundraiser">
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Start a Fundraiser
                </Link>
              </Button>
            </div>
          </nav>
        </div>
      </SheetContent>
    </Sheet>
  )
}

