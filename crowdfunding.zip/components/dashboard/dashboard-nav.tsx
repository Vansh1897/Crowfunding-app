"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { LayoutDashboard, Heart, Bell, Settings, CreditCard, User, PlusCircle } from "lucide-react"

const navItems = [
  {
    title: "Overview",
    href: "/dashboard",
    icon: <LayoutDashboard className="mr-2 h-4 w-4" />,
  },
  {
    title: "My Campaigns",
    href: "/dashboard/campaigns",
    icon: <Heart className="mr-2 h-4 w-4" />,
  },
  {
    title: "My Donations",
    href: "/dashboard/donations",
    icon: <CreditCard className="mr-2 h-4 w-4" />,
  },
  {
    title: "Notifications",
    href: "/dashboard/notifications",
    icon: <Bell className="mr-2 h-4 w-4" />,
  },
  {
    title: "Profile",
    href: "/dashboard/profile",
    icon: <User className="mr-2 h-4 w-4" />,
  },
  {
    title: "Settings",
    href: "/dashboard/settings",
    icon: <Settings className="mr-2 h-4 w-4" />,
  },
]

export function DashboardNav() {
  const pathname = usePathname()

  return (
    <nav className="grid gap-2">
      {navItems.map((item) => (
        <Link key={item.href} href={item.href}>
          <Button
            variant={pathname === item.href ? "default" : "ghost"}
            className={cn("w-full justify-start", pathname === item.href ? "" : "hover:bg-muted hover:text-foreground")}
          >
            {item.icon}
            {item.title}
          </Button>
        </Link>
      ))}
      <div className="mt-4">
        <Button className="w-full" asChild>
          <Link href="/start-fundraiser">
            <PlusCircle className="mr-2 h-4 w-4" />
            Start a Fundraiser
          </Link>
        </Button>
      </div>
    </nav>
  )
}

