"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar } from "lucide-react"
import { formatDate } from "@/lib/utils"

interface Update {
  id: string
  title: string
  content: string
  createdAt: string
}

interface CampaignUpdatesProps {
  updates: Update[]
}

export default function CampaignUpdates({ updates }: CampaignUpdatesProps) {
  return (
    <div className="space-y-6">
      {updates.length > 0 ? (
        updates.map((update, index) => (
          <motion.div
            key={update.id || index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className="overflow-hidden hover:shadow-md transition-shadow">
              <CardHeader className="pb-2 bg-muted/50">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{update.title}</CardTitle>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Calendar className="mr-1 h-4 w-4" />
                    {formatDate(update.createdAt)}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="prose prose-sm max-w-none dark:prose-invert">
                  {update.content.split("\n").map((paragraph, i) => (
                    <p key={i}>{paragraph}</p>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))
      ) : (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No updates yet. Check back later for campaign updates.</p>
        </div>
      )}
    </div>
  )
}

