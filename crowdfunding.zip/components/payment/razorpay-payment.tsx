"use client"

import { useState } from "react"
import Script from "next/script"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Icons } from "@/components/icons"

interface RazorpayPaymentProps {
  orderId: string
  amount: number
  currency: string
  name: string
  description: string
  image?: string
  prefill?: {
    name?: string
    email?: string
    contact?: string
  }
  theme?: {
    color?: string
  }
  onSuccess: (paymentId: string, orderId: string, signature: string) => void
  onFailure: (error: any) => void
}

declare global {
  interface Window {
    Razorpay: any
  }
}

export function RazorpayPayment({
  orderId,
  amount,
  currency,
  name,
  description,
  image,
  prefill,
  theme,
  onSuccess,
  onFailure,
}: RazorpayPaymentProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [isScriptLoaded, setIsScriptLoaded] = useState(false)

  // In a real application, this would come from an environment variable
  const razorpayKeyId = "rzp_test_your_key_id"

  const handlePayment = () => {
    setIsLoading(true)
    setError(null)

    if (!window.Razorpay) {
      setError("Razorpay SDK failed to load")
      setIsLoading(false)
      return
    }

    const options = {
      key: razorpayKeyId,
      amount: amount,
      currency: currency,
      name: name,
      description: description,
      image: image,
      order_id: orderId,
      handler: (response: any) => {
        onSuccess(response.razorpay_payment_id, response.razorpay_order_id, response.razorpay_signature)
      },
      prefill: prefill,
      theme: theme || { color: "#3B82F6" },
      modal: {
        ondismiss: () => {
          setIsLoading(false)
        },
      },
    }

    try {
      const razorpay = new window.Razorpay(options)
      razorpay.open()
    } catch (err) {
      console.error("Razorpay error:", err)
      setError("Failed to initialize payment. Please try again.")
      onFailure(err)
      setIsLoading(false)
    }
  }

  return (
    <div className="w-full">
      <Script
        src="https://checkout.razorpay.com/v1/checkout.js"
        onLoad={() => setIsScriptLoaded(true)}
        onError={() => setError("Failed to load Razorpay SDK")}
      />

      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Button onClick={handlePayment} disabled={isLoading || !isScriptLoaded} className="w-full group">
        {isLoading ? (
          <>
            <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />
            Processing...
          </>
        ) : (
          <>
            Pay {currency} {(amount / 100).toFixed(2)}
            <Icons.arrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
          </>
        )}
      </Button>
    </div>
  )
}

