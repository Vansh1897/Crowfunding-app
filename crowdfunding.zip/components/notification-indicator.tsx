"use client"

import { useEffect, useState } from "react"
import { Badge } from "@/components/ui/badge"
import { useSession } from "next-auth/react"

export function NotificationIndicator() {
  const { data: session } = useSession()
  const [count, setCount] = useState(0)

  useEffect(() => {
    if (!session?.user) return

    // Fetch notification count
    const fetchNotificationCount = async () => {
      try {
        const response = await fetch("/api/notifications/count")
        const data = await response.json()
        setCount(data.count)
      } catch (error) {
        console.error("Error fetching notification count:", error)
      }
    }

    fetchNotificationCount()

    // Set up polling for notifications
    const interval = setInterval(fetchNotificationCount, 60000) // Check every minute
    return () => clearInterval(interval)
  }, [session])

  if (count === 0) return null

  return (
    <Badge
      variant="destructive"
      className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
    >
      {count > 9 ? "9+" : count}
    </Badge>
  )
}

